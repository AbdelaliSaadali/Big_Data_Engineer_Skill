# Data Engineering Design / Delivery Review

## Architecture
- [ ] Business objective and user/consumer clearly defined
- [ ] Workload quantified with evidence/assumptions and peak/recovery headroom
- [ ] Components, responsibilities, interfaces and alternatives documented
- [ ] No unjustified broker, compute engine, duplicate DB, Kubernetes or warehouse

## Modeling and correctness
- [ ] OLTP PK/FK/constraints or analytical grain/metrics/SCD explicitly modeled
- [ ] Event IDs, UTC/time semantics, late data and schema evolution defined
- [ ] Replay, idempotency, source offset and output transactions considered
- [ ] Test cases with input→operation→expected output

## Operation
- [ ] Quality/quarantine, retention, owners, catalog/lineage and data contracts
- [ ] IAM, encryption/secrets, tenancy and sensitivity handling verified
- [ ] Logs, metrics, traces, freshness, SLI/SLO and actionable alerts
- [ ] Query plans/performance and cost characterized under real load
- [ ] Backup/restore and RPO/RTO tested within declared failure scope
- [ ] Deployment, schema migration, rollback, runbook and ADR present
- [ ] All measurements actual; anything untested explicitly pending
