# POC and validation plan

Decision under test:
Candidate version / infrastructure / cost basis:
Sample data origin and privacy classification:
Assumptions to falsify:

| Test | Setup | Expected invariant / threshold | Measured | Pass / fail |
|---|---|---|---|---|
| Functional path | one event per major source | input matches defined output | pending | pending |
| Duplicate/retry | emit same event twice | no incorrect duplicate effect | pending | pending |
| Late/out-of-order | out-of-order event time | meets documented policy | pending | pending |
| Malformed/schema change | invalid payload | quarantine/error with traceability | pending | pending |
| Peak throughput | sustained measured peak | >= agreed target | pending | pending |
| Freshness | end-to-end timestamps | >= agreed p99 SLO | pending | pending |
| Outage | stop processing/sink safely in test | recover within RTO, reconcile | pending | pending |
| Backup | restore isolated copy | RPO and data checks | pending | pending |
| Security | unauthorized role / tenant | access rejected and audited | pending | pending |
| Cost | model actual usage | within agreed budget | pending | pending |

Evidence links: query plans, logs, dashboards, CI report, reproducible scripts.
Result: accepted / rejected / unverified.
Issues, mitigations, re-test date and owner:
