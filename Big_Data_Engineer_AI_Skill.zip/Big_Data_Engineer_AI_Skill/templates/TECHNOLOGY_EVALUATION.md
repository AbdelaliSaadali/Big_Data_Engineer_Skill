# Technology selection — one component role at a time

Decision and workload:
Why does this role need to exist?:
Hard requirements (measurable):
Alternative: **omit component / reuse existing system** — feasible? why?:

## Hard-constraint screen
| Candidate architecture | Security / hosting | Functional | Correctness | Cost ceiling | Viable? |
|---|---|---|---|---|---|
| Keep existing | | | | | |
| A | | | | | |
| B | | | | | |

Do **not** score rejected candidates. Record explicit unknowns rather than guessed passes.

## Weighted viable-candidate scorecard
Scores 1–5, weights sum to 100%; evidence sources required; scoring is subjective until POC.
| Criterion | Weight | A score | B score | Evidence / assumption |
|---|---:|---:|---:|---|
| Functional fit | 30% | | | |
| Operation complexity | 20% | | | |
| TCO | 20% | | | |
| Performance | 15% | | | |
| Growth/portability | 15% | | | |

`weighted_total = sum(weight_fraction × score)`

## Outcome
Preferred candidate (proposed, or accepted with evidence):
Rejected and why:
POC acceptance criteria and measurement environment:
TCO assumptions, uncertainty and vendor-exit strategy:
Risk/trade-off accepted:
Revisit trigger:
Linked ADR:
