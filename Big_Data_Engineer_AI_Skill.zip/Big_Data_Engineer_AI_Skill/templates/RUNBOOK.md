# Runbook — [Pipeline/Service]

Owner / on-call / approved environments:
Impacted sources, targets and data classification:
SLO, RPO, RTO, last verified restore date:

## Detection
Alert and exact symptoms, dashboard links, timestamp range, business impact.

## Safe first checks
1. Identify first boundary with lost/delayed progress (API/broker/processor/sink).
2. Compare event IDs, timestamps, input/output rates, partition lags and checkpoints.
3. Inspect recent deployments/DDL/source contracts and resource saturation.
4. Determine whether data is delayed or permanently unavailable.

## Approved recovery actions
Preconditions: authorization, reliable backup, known input positions, compatible code and schema.
Commands/parameters: **fill for actual environment; none assumed**.
Stop/escalate conditions and rollback:

## Validation
- Source→sink reconciliation for affected event IDs/time window:
- No duplicate grain rows or incorrect aggregates:
- Processing state / checkpoint and source retention valid:
- Dataset freshness and SLI/SLO recovered:
- Actual RPO/RTO achieved:

## Incident closeout
Root-cause evidence; affected data repaired or quarantined; limitations; owner and preventative tests.
