# Project intake — Data Engineering

Project / stakeholders / target users:
Business problem and success metric:
What decision/action must the final data support?:

## Sources
- Systems, owners and read permissions:
- Protocol/API/DB/file and example records:
- Authoritative source of truth and business event key:
- Volume (daily, average and peak) + evidence:
- Updates, deletions, late arrivals and timestamp semantics:

## Required outputs
- Consumer (API, BI, ML, alert) and access control:
- Fact grain and metric definition:
- Freshness/latency p95/p99:
- Historical queries, retention and expected growth:

## Constraints
- Mandatory: hosting, compliance, cost ceiling, team, deadlines, access, correctness, durability:
- Desired: portability, developer ease, provider preference:
- RPO/RTO and expected incident scope:
- Existing systems to reuse:

## Unknowns, assumptions and validation
| Statement | Fact / assumption / unknown | Evidence needed | Owner |
|---|---|---|---|
| | | | |

Decision needed now:
Scope for MVP:
Criteria to reject a candidate:
