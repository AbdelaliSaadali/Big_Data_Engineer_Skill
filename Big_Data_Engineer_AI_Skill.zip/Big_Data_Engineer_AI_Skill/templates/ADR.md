# ADR-XXX — [Decision]

- **Status:** Proposed / Accepted / Superseded
- **Date:** YYYY-MM-DD
- **Owner and reviewers:**
- **Supersedes / is superseded by:**

## Context / problem
What data workload and business goal must the architecture serve? Link intake and evidence.

## Requirements and hard constraints
List measurable functional/nonfunctional conditions, privacy/compliance and cost ceiling. State unknowns.

## Candidates considered
Include simplest viable architecture and the option to reuse existing services. Eliminate noncompliant options before score comparisons.

## Decision
Selected architecture and specific technology versions only if validated. State proposed vs deployed.

## Rationale / evidence
Workload estimates, POC results, benchmark methodology, correctness tests and cost model. Label assumptions.

## Consequences
Benefits, accepted disadvantages, operational complexity, owner, failure modes, TCO, privacy and lock-in risks.

## Validation and migration plan
Build/test/cutover/rollback, reprocessing, access controls, expected data invariants.

## Revisit triggers
SLO breach, workload growth, cost/ops burden, security/regulatory or ecosystem change, newer measurements.
