# Example engineering decision: e-commerce analytics ingestion

> Educational hypothetical requirements; no actual production validation.

## Business request
Finance needs daily revenue by product and region. Products and orders are stored transactionally in PostgreSQL. Start with overnight freshness. Consider CDC only if business later needs sub-minute updates.

## Candidate A — Nightly ELT
```
PostgreSQL OLTP → bounded extraction of approved tables
  → warehouse staging (source snapshot and manifest)
  → dbt validated staging + dimensions + fact order item
  → published mart → BI with governed metric
```
Airflow schedules and coordinates, but data moves through storage/SQL, not necessarily through the scheduler. Requires a reliable extract watermark or snapshot consistency across joined tables; define retry and late source updates. With small volumes, this may be simplest.

## Candidate B — CDC / event log
```
PostgreSQL WAL + consistent initial snapshot
  → Debezium CDC → Kafka / managed log → warehouse landing
  → deduplicated upserts/deletes + dimensional history
  → curated paid-order mart → BI
```
Use only if low-lag availability, multiple independent consumers or change history justify additional cluster/connectors and operational burden.

## Modeling is independent from candidate
Declare *one row per order item* in `fact_order_item`. `orders(order_id, customer_id, status, ordered_at)`, `order_items(order_id, line_no, product_id, qty, unit_price, currency)`, `payments(payment_id, order_id, status, captured_amount, currency)`.
- Joining all payments to all items can multiply amount. Define finance-recognized revenue at correct authoritative grain and statuses; refunds/taxes/discount/currency conversion need business rules.
- Handle paid→refunded transitions and historical late corrections. If SCD2 dimensions, join by effective times with stable surrogate keys.
- Source reconciliation: by order IDs and date, distinct event IDs, captured amounts and accepted exclusion logic, not raw row counts only.

## Hard constraints / decision
If overnight reporting meets target, A can satisfy requirements without Kafka. If <60s freshness is mandatory and source supports correct CDC, B is viable pending cost and source-to-sink failure tests. Do not make architectural choice based on CDC popularity.

## POC tests
- Initial snapshot and WAL changes during snapshot produce consistent target.
- Update, delete, payment refund correctly propagated or reconciled.
- Rerunning same source window does not duplicate `fact_order_item` or revenue.
- BI definition tested with sample invoices, different currencies and date boundaries.
- User role cannot access unrelated financial identifiers.
- Late correction rebuilds exact affected mart grain.
- Compare cost/latency/recovery with actual workload; evidence pending.
