# Example design review: small IoT operational monitoring

> **Status: educational proposal / design exercise.** Workload estimates and test outcomes are not real benchmark evidence. This example demonstrates how to apply the skill, not an existing deployment.

## 1. Business outcome
Site operators need to see the last valid power measurement from authorized devices within a 10-second freshness objective and review 30 days of approved historical readings. One app consumes the data; there is no requirement for historical replay across independent consumers.

## 2. Intake assumptions / volume
- 200 devices emitting once per 30 seconds, approximately 500 bytes per record, typical average 6.67 records/s, logical 288 MB/day (decimal units); a 10× burst ~67 records/s to be tested.
- Device events carry stable `(source,event_id)`, `device_id`, `event_time`, `power_w`, `site_id` authoritative from metadata; duplicate QoS retransmissions possible.
- Hosting: modest server, experienced Python/PostgreSQL, one operator; no proven need for distributed stateful processing.
- Unknown: device offline storage, source clock drift, actual database retention/compression and peak query concurrency.

## 3. Architecture proposal (simplest candidate)
```
Shelly / test MQTT publishers
     └── TLS/MQTT → EMQX
                      └── subscribed FastAPI service
                              ├── validate event/site/device schema
                              ├── quarantine invalid + audit count
                              ├── PostgreSQL → device and site metadata
                              └── InfluxDB → telemetry event/time series
                                                  └── authorized dashboard API
```
**Kafka, Flink, a lakehouse and Kubernetes intentionally omitted**, because no requirement has justified them yet. InfluxDB is also replaceable by PostgreSQL/TimescaleDB if measurements show that a single database is operationally preferable.

## 4. Contract and model
```json
{"source":"gateway-A","event_id":"D17-00012","device_id":"D17","event_time":"2026-10-18T11:00:00Z","power_w":310.0}
```
Operational SQL (illustrative; adapt to actual device registry):
```sql
CREATE TABLE device (
 device_id text PRIMARY KEY,
 site_id text NOT NULL,
 display_name text
);
CREATE TABLE accepted_event_registry (
 source text NOT NULL,
 event_id text NOT NULL,
 device_id text NOT NULL REFERENCES device(device_id),
 ingested_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY (source,event_id)
);
```
Ingest dedup design: accept broker delivery only after app-defined durable write boundary, if consistent with MQTT ack mode; stable logical event ID prevents repeated external effect. A DB registry + TSDB dual-write **is not atomic**: must define a reconciliation or outbox mechanism, or choose a single transactional store for accepted-event ledger and telemetry where possible. Don't claim exactly-once merely from a unique constraint in one store.

Analytical grain: one validated measurement event per device/event ID. Dashboard recent metric uses max `ingested_at` or event-time freshness with clock skew policy, scoped per authorized site/device. Power is instantaneous W; never call its simple sum energy consumption.

## 5. Quality/security/observability
- Check required event key, numeric units, known device and timestamp; invalid to restricted quarantine with reason (avoid logging sensitive raw payload).
- Per-site permissions in API and DB, workload credentials distinct from user access, encrypted connections, retention for raw and registry, access audit.
- Monitor MQTT connections and error rate, accepted/rejected/duplicate events/s, DB latency, per-device freshness, missing-device count, storage volume and resource saturation.
- Owner for each dataset and runbook; catalog/lineage can be lightweight documentation at this scale.

## 6. Failure cases and actions
- Offline device: messages not sent cannot be recovered absent device buffering; record coverage gaps.
- API restarts: verify MQTT replay delivery semantics and dedup across restart.
- DB unavailable: bounded retries/durable upstream buffer or explicit reject/ack policy; test no silent accepted-but-lost records.
- Backup/restore: separate PostgreSQL/InfluxDB recovery and cross-system reconciliation; define RPO/RTO before production.

## 7. POC acceptance criteria (PENDING)
| Test | Target | Observed |
|---|---|---|
| Sustained 10× peak | ~67 events/s without unbounded queue | not run |
| Per-device p99 freshness | <=10s from agreed source reference | not run |
| Duplicate delivery | no duplicate logical effect | not run |
| DB outage and recovery | correct detection/retry/recovery | not run |
| Site A requests site B data | denied and logged | not run |

## 8. ADR summary
**Proposed:** start with existing MQTT + API + metadata/TSDB architecture, subject to tests. **Reconsider:** independent replay consumers, stateful event-time windows, tested capacity failure, higher resilience requirements. Alternative Kafka + Flink is not forbidden; it requires a new justification and measured POC.
