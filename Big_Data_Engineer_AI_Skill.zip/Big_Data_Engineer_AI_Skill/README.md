# Big Data Engineer AI Skill — Practical, Portable Package

A reusable, source-grounded engineering agent skill built from the owner's **46 exported PDFs** (45 technical learning notes and one roadmap/index; extracted text spans 1,061 PDF pages) plus the final **28.01 Technology Selection Playbook** from this conversation, which was not included in the PDF export.

## What this skill lets an AI do
- Translate business goals into requirements and measurable workload estimates.
- Model operational (ER/normalized) and analytical (grain/fact/dimension/SCD) data.
- Decide file formats, lakehouse table formats, relational/NoSQL/OLAP/specialized databases.
- Select direct ingestion, MQTT, event queues/logs, Kafka/Pulsar, CDC/outbox and stream semantics.
- Design/implement batch, Spark, Flink, SQL, dbt, Airflow and mixed real-time/BI paths.
- Build quality rules, governance/lineage, access controls, SLOs, dashboards and recoverable pipelines.
- Diagnose SQL plans, Spark skew, Kafka lag, Flink backpressure and storage/network bottlenecks.
- Estimate TCO, choose deployment, test POCs, create ADRs and manage evolution.

## Layout
```
Big_Data_Engineer_AI_Skill/
├── SKILL.md                 # Entry point and engineering instructions
├── README.md                # This guide
├── PASTE_INTO_ANY_AI.md     # Copy/paste onboarding prompt
├── references/              # 14 applied engineering playbooks + source map
├── templates/               # Intake, data contract, scorecard, POC, ADR, runbook
├── examples/                # Fully explained design exercises
├── knowledge/source_notes/ # Extracted text from the original 46 PDFs
└── tests/                   # Package integrity validation
```

## Installation / use
**Agents supporting SKILL.md folders:** copy the whole `Big_Data_Engineer_AI_Skill` directory into your platform's skills directory. The precise location/activation rules vary by product; don't assume a universal path. The agent should load `SKILL.md`, then only the relevant references and source notes as tasks arise.

**General AI chats or projects without a Skills API:** upload the zip or its folder files if your app supports it, and start with `PASTE_INTO_ANY_AI.md`. If the AI cannot read folders/zip files, give it `SKILL.md` and the relevant domain references separately.

**Example task prompts:**
- “Use the Big Data Engineer skill. Design an IoT backend for 2,000 MQTT devices with 10s freshness, 90d telemetry and only one engineer; choose the simplest stack. Include ER model, data contracts, POC and ADR.”
- “Use this skill to review my Airflow/dbt warehouse pipeline. Determine if incremental models, SCD2, source freshness, lineage, tenant access and replay are correct. Identify evidence I need to provide.”
- “My Kafka consumer lag is rising while CPU is low. Diagnose step-by-step using observability evidence, do not recommend scaling without isolating the bottleneck.”
- “Implement a small ELT pipeline with schema migrations, tests, quarantined rejects, data contracts, lineage and a runbook.”

## Source and scope notes
- Notes are **text extracts** created from the Apple Notes exported PDFs. Text, headings and some table layouts may be imperfectly flattened. For exact original screenshots and drawings, consult the user's original export.
- `references/SOURCE_MAP.md` links source note numbers to extracted content. The course source notes are not silently overwritten or corrected; operational guides synthesize them into actionable processes and may add general best-practice framing.
- Some source notes contain illustrative snippets/technology versions. Production operations require validating current vendor/version docs and testing in the target environment.
- This package includes source text, not the original 331 MB attachments ZIP. The owner already supplied the original separately.
- The skill is an **instruction and knowledge resource**, not a pre-authorized connector, credential, deployed platform or guarantee of agent expertise. Correct engineering still requires genuine project context, tool access, tests and human approval for impactful changes.

## Quick start
1. Give the entire folder/zip to your AI.
2. Tell it to read `SKILL.md` first.
3. Describe your project and supply facts/data or code (not secrets).
4. Ask for **architecture + modeling + implementation + cross-cutting controls + proof**, with explicit assumptions and alternatives.
5. Review generated decisions, tests and actual deployment evidence before production use.
