# ROADMAP — Big Data

Source: Apple Notes Export.zip > Big Data > Big Data.pdf > Big Data.pdf

---

[[PAGE 1]]
Big Data
│
├── 00 — Data Field Overview
│   ├── 00.01 — What Is the Data Field?
│   ├── 00.02 — Data Roles: Engineer, Analyst,
Scientist, DBA
│   └── 00.03 — Big Data Explained
│
├── 01 — Data Fundamentals
│   └── 01.01 — Data Fundamentals & Workload
Vocabulary
│       Structured / semi-structured / unstructured
│       Data at rest vs data in motion
│       Operational vs analytical data
│       Batch vs streaming
│       Latency, throughput, scalability, durability
│
├── 02 — SQL & Relational Databases
│   ├── 02.01 — Relational Model & SQL Fundamentals
│   ├── 02.02 — Joins, Aggregations, Subqueries, CTEs
& Window Functions
│   └── 02.03 — How Relational Databases Work
│       Transactions, ACID, indexes, query execution,
│       constraints, locks, isolation, normalization
│
├── 03 — Data Modeling & Schemas
│   ├── 03.01 — Operational Data Modeling
│   │   ER modeling, normalization, keys,
relationships
│   └── 03.02 — Analytical Data Modeling
│       Facts, dimensions, star/snowflake schemas,
│       denormalization, SCD
│
├── 04 — Distributed Systems
│   ├── 04.01 — Distributed Systems Fundamentals
│   │   Nodes, clusters, network failures, CAP
│   ├── 04.02 — Partitioning, Replication &
Consistency
│   │   Sharding, replicas, quorum, consistency
models
│   └── 04.03 — Coordination & Fault Tolerance
│       Leaders, consensus concepts, ZooKeeper,
│       failure detection, recovery
│
├── 05 — Storage & File Formats
│   ├── 05.01 — How Data Is Stored
│   │   Row vs column storage, blocks, pages,
│   │   compression, serialization
│   └── 05.02 — Data File Formats
│       CSV, JSON, Avro, Parquet, ORC
│       + when to use each
│

[[PAGE 2]]
├── 06 — Hadoop Ecosystem
│   ├── 06.01 — Hadoop Core
│   │   HDFS, YARN, MapReduce
│   └── 06.02 — Hadoop Ecosystem & Its Modern
Relevance
│       Hive, HBase, ZooKeeper, Sqoop, Flume,
│       Oozie, Pig + what replaced/modernized them
│
├── 07 — NoSQL Databases
│   ├── 07.01 — NoSQL Fundamentals & Database
Families
│   │   Key-value, document, wide-column, graph
│   │   SQL vs NoSQL
│   └── 07.02 — MongoDB, Cassandra, HBase & Redis
│       Architecture, use cases and comparisons
│
├── 08 — Analytical & OLAP Databases
│   └── 08.01 — OLAP Systems & Analytical Databases
│       OLTP vs OLAP, columnar engines, MPP,
│       ClickHouse and modern analytical systems
│
├── 09 — Specialized Databases
│   └── 09.01 — Time-Series, Search & Graph Databases
│       InfluxDB / Timescale
│       Elasticsearch / OpenSearch
│       Neo4j
│       + when each model makes sense
│
    10 — Messaging & Event Streaming
    │
    ├── 10.01 — Messaging & Event Streaming
Fundamentals
    │           Queues, pub/sub, events, brokers,
    │           delivery semantics, Kafka vs RabbitMQ
    │
    ├── 10.02 — Apache Kafka Architecture
    │           Brokers, topics, partitions, offsets,
    │           consumer groups, replication, KRaft
    │
    ├── 10.03 — Kafka in Real Systems
    │           Kafka Streams, scaling, failures,
    │           event-driven patterns
    │
    ├── 10.04 — MQTT & IoT Messaging Systems
    │           MQTT, EMQX, Mosquitto, HiveMQ,
    │           QoS, sessions, IoT architectures
    │
    └── 10.05 — Cloud Messaging & Alternative Systems
                SQS, SNS, Kinesis, MSK,
                Google Pub/Sub, Azure Event Hubs,
                Azure Service Bus, NATS,
                Pulsar, Redis Streams
│

[[PAGE 3]]
├── 11 — Data Processing Engines
│   ├── 11.01 — Distributed Data Processing
Fundamentals
│   │   Parallelism, DAGs, stages, tasks,
│   │   shuffle, data locality
│   ├── 11.02 — Apache Spark
│   │   Architecture, RDD/DataFrame,
│   │   transformations/actions, shuffle,
│   │   Spark SQL, Structured Streaming
│   └── 11.03 — Apache Flink & Stream Processing
│       Stateful streaming, windows, checkpoints,
│       event time, watermarks, Spark vs Flink
│
├── 12 — Data Lakes & Object Storage
│   └── 12.01 — Data Lakes, HDFS & Object Storage
│       S3 / ADLS / GCS / MinIO
│       Architecture, partitioning, file layout,
│       data lake strengths and problems
│
├── 13 — Lakehouse & Table Formats
│   └── 13.01 — Lakehouse Architecture & Table
Formats
│       Lake vs warehouse vs lakehouse
│       Delta Lake, Iceberg, Hudi
│       ACID, snapshots, schema evolution, time
travel
│
├── 14 — Data Warehousing & Distributed SQL
│   ├── 14.01 — Data Warehouses from Fundamentals to
Modern Systems
│   │   Warehouse architecture, ETL/ELT,
│   │   dimensional modeling, MPP,
│   │   Snowflake/BigQuery/Redshift/Fabric concepts
│   └── 14.02 — Distributed SQL Query Engines &
Federation
│       Trino, Presto, Athena, DuckDB
│       Coordinators, workers, connectors,
│       federated queries, pushdown, materialization
│
├── 15 — ETL, ELT & Data Integration
│   └── 15.01 — ETL, ELT & Data Integration Patterns
│       Batch ingestion, APIs, files, databases,
│       staging, transformations, loading
│
├── 16 — CDC & Real-Time Data Movement
│   └── 16.01 — Change Data Capture
│       Log-based CDC, database logs,
│       Debezium, Kafka, snapshots,
│       ordering and consistency
│
├── 17 — Orchestration & Workflow
│   └── 17.01 — Data Orchestration
│       DAGs, scheduling, dependencies, retries,

[[PAGE 4]]
│       backfills, Airflow concepts
│
├── 18 — Data Transformation
│   └── 18.01 — Data Transformation & dbt
│       Cleaning, joins, aggregations,
│       transformation layers, dbt,
│       testing and modular SQL
│
├── 19 — Analytics & BI
│   └── 19.01 — Analytics, Metrics & Business
Intelligence
│       KPIs, semantic layers, dashboards,
│       Power BI/Tableau concepts
│
├── 20 — Data Quality
│   └── 20.01 — Data Quality Engineering
│       Accuracy, completeness, uniqueness,
│       freshness, validity, tests, data contracts
│
├── 21 — Data Governance, Metadata & Lineage
│   └── 21.01 — Governance, Metadata, Catalogs & Data
Lifecycle
│       Technical/business metadata, catalog
architecture,
│       data discovery, lineage, ownership,
stewardship,
│       classification, retention, deletion,
lifecycle policies
│       DataHub, OpenMetadata, Apache Atlas
│
├── 22 — Data Security
│   └── 22.01 — Data Security Fundamentals
│       Authentication, authorization, IAM/RBAC,
│       encryption, masking, secrets,
│       network security, auditing
│
├── 23 — Observability & Monitoring
│   └── 23.01 — Data Observability
│       Logs, metrics, traces, pipeline health,
│       freshness monitoring, failures, alerts,
│       SLIs/SLOs, Prometheus, Grafana
│
├── 24 — Infrastructure for Data Platforms
│   └── 24.01 — Docker, Kubernetes & Cloud
Infrastructure
│       Linux, containers, Docker, Kubernetes,
│       compute/storage/network concepts,
│       cloud deployment and scaling
│
├── 25 — Performance Engineering & Troubleshooting
│   └── 25.01 — Optimizing & Troubleshooting Data
Systems
│       Query plans, indexing, caching, partitioning,

[[PAGE 5]]
│       shuffle, skew, bottlenecks, Kafka lag,
│       slow pipelines, storage and network problems,
│       systematic diagnosis and optimization
│
├── 26 — Reliability & Recovery
│   └── 26.01 — Reliable Data Systems & Disaster
Recovery
│       End-to-end fault tolerance, failure recovery,
│       backups, restore, RPO/RTO, replay,
│       delivery correctness, resilience testing
│
├── 27 — Data Architecture & System Design
│   ├── 27.01 — Architecture Patterns & How to Design
a Data System
│   │   Requirements → workload → architecture →
technology
│   │   Lambda, Kappa, medallion, event-driven,
│   │   data mesh, batch/stream design patterns
│
├── 28 — Technology Selection
│   └── 28.01 — Choosing the Right Data Technology
│       Given workload → requirements → constraints
│       → trade-offs → technology choice
│       Real architecture decisions and scenarios
│
└── 99 — MASTER DATA ARCHITECTURE
    └── 99.01 — Everything Connected
        One complete architecture connecting:
        sources, ingestion, streaming, storage,
        processing, transformation, serving,
        analytics, quality, security, governance,
        observability and reliability