"""Read-only, standard-library verification of portable skill package."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
assert (root / 'SKILL.md').exists()
assert (root / 'README.md').exists()
assert (root / 'PASTE_INTO_ANY_AI.md').exists()
assert (root / 'references' / 'SOURCE_MAP.md').exists()
ref_names = {p.name for p in (root / 'references').glob('*.md')}
assert len(ref_names) == 15, (len(ref_names), sorted(ref_names))
sources = list((root / 'knowledge' / 'source_notes').glob('*.md'))
assert len(sources) == 46, f'Expected 46 extracted sources; got {len(sources)}'
required = ['templates/PROJECT_INTAKE.md','templates/ADR.md', 'templates/DATA_CONTRACT.yaml',
            'templates/TECHNOLOGY_EVALUATION.md','templates/VALIDATION_PLAN.md',
            'templates/RUNBOOK.md','templates/DELIVERY_REVIEW.md']
for file in required:
    assert (root / file).exists(), file
for p in (root / 'references').glob('*.md'):
    for target in re.findall(r'\]\((\.{1,2}/[^)]+)\)',p.read_text()):
        assert (p.parent / target).resolve().exists(), f'Broken link {p}: {target}'
text = (root / 'SKILL.md').read_text()
assert text.startswith('---\nname: big-data-engineer\n')
assert 'Mandatory engineering behavior' in text
assert 'Never claim' not in text or 'claim' in text.lower()
print(f'PASS: {len(ref_names)} reference files, {len(sources)} course extracts, required templates and working source-map links.')
