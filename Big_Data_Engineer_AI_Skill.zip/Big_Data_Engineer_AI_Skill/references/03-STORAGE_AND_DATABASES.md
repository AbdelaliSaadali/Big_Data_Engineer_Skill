# Storage, file formats, databases and lakehouse technology selection

**Curriculum grounding:** 05.01–05.02 storage/formats; 06 Hadoop; 07 NoSQL; 08 OLAP; 09 specialized DBs; 12 data lakes/object storage; 13 table formats; 14 warehousing and federated SQL. These are capabilities and trade-offs, not a vendor ranking.

## A. First separate four different questions
1. **Data model & interaction**: transactions? key lookups? graph traversal? search relevance? time-range aggregates?
2. **Physical persistence**: row vs column oriented, OLTP records vs immutable files, cold vs hot.
3. **File serialization**: CSV, JSON, Avro, Parquet, ORC.
4. **Table / query layer**: raw files vs Iceberg/Delta/Hudi table format vs query engine (Trino/Spark/warehouse) vs dashboard engine.
Don't conflate object storage with a database, a file format with a table format, or an execution engine with storage.

## B. File format decision guide
| Format | Prefer when | Avoid / caveats | Validate |
|---|---|---|---|
| CSV | simple exports, broad interoperability | weak types, escaping, nested structures, ambiguous timestamps | delimiter, quote, null and schema contract |
| JSON / NDJSON | APIs, logs, debugging, flexible nested events | verbose; evolving nested semantics | required fields, versions, strict parsing |
| Avro | compact record-oriented events, strong schema compatibility | readers must respect registry/schema compatibility | writer/reader schema evolution |
| Parquet | columnar analytics, scans/pruning, compression | small files and row-level mutation challenges; nested mapping | row groups, compression, predicate & column pruning |
| ORC | columnar analytics, some Hive-oriented ecosystems | ecosystem compatibility | engine support, schema evolution |

Store raw source faithfully when needed; use validation/quarantine separately. Avoid unbounded tiny Parquet files. Compression decisions depend on real workload (CPU vs I/O trade-off).

## C. OLTP / NoSQL / specialized DB matrix
| Workload shape | Reasonable starting choices | Main selection tests |
|---|---|---|
| Transactions, FK relationships, structured updates | PostgreSQL / relational DB | ACID, query patterns, index/write trade-off |
| Flexible documents and nested object-oriented access | MongoDB | query and index patterns, embedded vs referenced data, transactions |
| Massive distributed write/read by known partition key | Cassandra | partition key/cardinality, consistency, compaction, query-first model |
| Wide-column low-latency lookup in Hadoop ecosystem | HBase | HDFS/infrastructure burden, key design |
| Fast ephemeral/key-value caching and counters | Redis | memory sizing, eviction, persistence, invalidation |
| Time-based telemetry queries | InfluxDB, TimescaleDB or capable SQL/OLAP engines | tags cardinality, retention, time windows, writes |
| Search, log filtering and full-text relevance | Elasticsearch / OpenSearch | search index, shards, field mapping and cost |
| Deep graph traversals | Neo4j/graph DB | edges, traversal query patterns vs relational joins |
| Aggregate analytical scans | ClickHouse, BigQuery, Snowflake, Redshift etc. | scan/query concurrency, ingest model, cost, data skipping |
| Lake data with transactional table semantics | Iceberg, Delta Lake, Hudi | engine/catalog interoperability, operations, CDC/upsert needs |
| Query multiple heterogeneous sources | Trino, suitable federated SQL | pushdown, cross-source join cost, consistency, security |

Never imply: "NoSQL always scales better", "time-series data always needs InfluxDB", "ClickHouse replaces transactional Postgres", or "Trino stores the queried data". Where existing application DB already meets throughput and correctness, reuse it.

## D. Object storage and analytics lake
- Object stores (S3, MinIO, Azure Blob, GCS) expose objects/keys, not HDFS-like POSIX filesystems. Read-after-write/atomic rename assumptions vary across engines/formats; use compatible connectors/committers.
- Lake architecture: ingestion → raw zone → validated/refined zone → curated analytical zone; Bronze/Silver/Gold logical layers when beneficial, not a mandatory physical cluster per layer.
- Use columnar Parquet for large scans; explicit partitions by useful low/moderate cardinality predicates such as day/month; avoid partitioning by per-event ID or second-level timestamps without evidence.
- Target sufficiently sized files based on engine and write frequency, not magic universal size. Plan compaction, schema evolution, vacuum/retention, catalogs and orphaned-file cleanup.
- Table formats provide transactions/metadata/snapshots over object storage. Snapshot metadata may reference the original files and is not independent backup. Readers need compatible catalog and file access.
- Warehouse vs lake vs lakehouse: select using query SLAs, governance/security, update semantics, data diversity, team ops capabilities and TCO, not architecture fashion.

## E. Practical decision examples
**Small IoT dashboard:** EMQX → FastAPI → InfluxDB telemetry + PostgreSQL metadata may suffice. Kafka/Flink are optional proposals only when decoupled durable replay or complex stateful processing is required.
**Heavy event analytics:** Kafka → stream processor → ClickHouse for recent aggregates, object storage + Parquet/Iceberg for long-term history. Check clickhouse ingest semantics, event-time correctness and query patterns.
**E-commerce OLTP:** PostgreSQL for orders/payments state. CDC or outbox to analytical path rather than using the warehouse as the transactional primary DB.
**Interactive operational log investigation:** structured logs → agent/collector → Elasticsearch/OpenSearch + Kibana; Prometheus + Grafana handles metrics separately; choose retention/cost policy.

## F. Storage and query design gates
- Document persistent durability, backup, retention and deletion path (including replicas and archives).
- Index/sort key/partition key matches actual WHERE/JOIN/ORDER BY and distribution; evaluate read vs write impact.
- Define cardinalities, query concurrency, hot/cold tiers, schema migration and per-tenant access.
- For lakehouse, record table/catalog/engine compatibility and checkpointed ingestion/upsert guarantees.
- Prototype access patterns with representative data. Never claim index tuning from a query name alone; inspect execution plan.
