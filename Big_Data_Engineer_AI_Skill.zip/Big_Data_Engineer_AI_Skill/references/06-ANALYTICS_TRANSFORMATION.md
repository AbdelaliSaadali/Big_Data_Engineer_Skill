# Warehousing, lakehouse, ETL/ELT, orchestration, metrics and serving

**Curriculum grounding:** 12–14 lakes/warehouses/federation, 15 ETL/ELT, 17 Airflow, 18 dbt, 19 analytics/BI, 13 Iceberg/Delta/Hudi, 21 governance. This guide organizes decisions; use original notes for full tool mechanics.

## A. Choose processing location and data contract
| Pattern | Data movement | When to evaluate | Cautions |
|---|---|---|---|
| ETL | transform before loading final analytical store | pre-load masking/validation, source-to-target constraints | transformation runtime and late fixes |
| ELT | raw/land then transform in warehouse/lakehouse | scalable SQL transformations, reprocessability | enforce raw access controls, query cost |
| CDC into analytics | log changes then upsert/merge | low-lag source DB replication to analytics | deletions, snapshot consistency, schema drift |
| Federated query | query sources without centralizing all data | occasional joins, exploratory access | remote IO, cross-source consistency, security |
| Stream materialization | continuous compute updates serving tables | latency-critical dashboards | corrections/upserts, sink and replay semantics |

## B. Data lake / warehouse / lakehouse design
- Raw landing immutable or auditable where retention permits; store payload, source ID, ingest timestamp, version, checksum/manifest, original operation.
- Silver/refined validated/deduplicated/conformed records; preserve rejects in quarantine; track corrected source records and lineage.
- Gold curated **business-grain** facts/dims/aggregate marts; governed metrics and dimensional history.
- Lakehouse tables: ACID metadata commits over object files, catalogs, snapshots, concurrent writers, schema evolution, compaction, vacuum and rollback. Do not treat snapshots as independent backups.
- Warehouse: separation of operational source and OLAP serving, controlled ingestion, clustering/partitioning, access rules, concurrency and credits/compute cost.
- Federated SQL: push down predicates/aggregates when available; beware transferring vast tables across remote systems to perform joins.

## C. Airflow orchestration requirements
- DAG = dependency/workflow plan; data generally flows between external storage/services, not through large XCom payloads.
- Tasks have explicit inputs/outputs, timeout, retries/backoff, pools/concurrency, idempotency, sensors/deferrable waiting where useful; respect data interval instead of `today()`.
- Backfill must be designed for upstream late changes and downstream rebuild dependencies.
- Task succeeded != data fresh/complete: check row counts, expected partitions, business SLA and publication markers.
- Operators should have least privilege; do not embed DB passwords in source control.

## D. dbt transformation contracts
- Define sources, staging models, intermediate models, marts, tests, documentation and lineage; align project conventions rather than mechanically calling staging=Bronze for every system.
- Incremental materialization needs explicit unique keys, strategies (`merge`, insert-overwrite where applicable), lookback window for late updates and corrected deletes.
- Model tests: unique, not_null, relationships, accepted_values and custom reconciliations; freshness on source ingestion; don't rely only on generic tests to assert KPI math.
- Document metric grain, numerator/denominator, currency, timezone and exclusions. Semantic layer contracts keep BI definitions consistent.

## E. Metrics and BI correctness
For every metric define: name, business question, fact grain, formula, dimensions, allowed filters, currency/unit/timezone, as-of policy, late corrections, aggregation safety and owner. Example:
```
orders_paid = COUNT(DISTINCT order_id WHERE status='paid')
gross_sales_mad = SUM(valid_paid_order_items.qty * unit_price_mad)
```
These definitions are illustrative: discount/refund/tax/currency timing must be defined before declaring actual revenue.

### Aggregation trap
Group A: 1 sale at 100 MAD; Group B: 9 sales at 10 MAD. Mean sale price across all 10 sales is `(100 + 9*10)/10=19`, not `(100+10)/2=55`. Always carry numerator and denominator, and avoid additive duplication after joins.

## F. Publish contracts
- Bronze access restricted as necessary; curated datasets can have SLA/SLI, owner, quality score, schema version, lineage and row/column access controls.
- Store publication event or watermark; downstream should know whether period/window is provisional or final.
- For dashboard load: decide direct serving DB vs materialized view vs semantic BI warehouse; caching requires refresh/invalidation consistent with freshness SLO.
- If data is sensitive (such as health-related risk features), restrict raw vs aggregate and enforce least privilege, retention and authorized use.

## G. Validation matrix
| Transition | Required evidence |
|---|---|
| Raw → refined | parse/schema, dedup, quarantined invalid, loss reconciliation |
| Refined → curated | grain uniqueness, referential integrity, metric formula test |
| Curated → dashboard | consistent filters/timezone, freshness, permissions |
| Source CDC → history | updates/deletes/ordering, snapshot handoff, lag |
| Restart/backfill → curated | idempotence, no duplicate logical effects, revised partitions |
