# Batch, distributed, SQL and stream processing

**Curriculum grounding:** 04 distributed fundamentals; 06 Hadoop's historical role; 11.01 processing primitives, 11.02 Spark, 11.03 Flink; 10.03 Kafka Streams; 25 optimization.

## A. Select computational style before engine
| Requirement | Consider | Important cost/semantic issue |
|---|---|---|
| Small local cleaning/aggregation | SQL/Python/Pandas | no cluster overhead; data fits memory? |
| Large bounded transforms | Warehouse SQL, Spark, Trino/other SQL | partition pruning, shuffles, source/target placement |
| Micro-batch incremental updates | Spark Structured Streaming or scheduled incremental SQL | trigger behavior, checkpoint semantics, latency |
| Low-latency stateful event-time logic | Flink | watermarks, keying, state TTL, checkpoints, sink guarantees |
| Stateful services around Kafka with moderate scope | Kafka Streams | Kafka binding, local state/rebalances |
| Daily deterministic marts | dbt/SQL scheduled by orchestrator | source snapshots, incremental merge, late updates |

A distributed engine is not a replacement for an inefficient algorithm or missing index. Some operators perform better directly within a warehouse.

## B. Distributed execution contract
- Define input partitioning, transformations and physical stages; wide operations (join, groupBy, orderBy, distinct) may trigger shuffle; narrower pipelining avoids extra movement.
- Estimate key cardinality and skew, partition sizes, executor/task slots, memory/GC and spill. A handful of enormous partitions can dominate runtime even with many workers.
- Do not blindly `repartition(1000)`, broadcast enormous tables or `cache()` every DataFrame. Inspect actual Spark UI query DAG, spill and shuffle stats, stage/task duration distributions.
- For joins define cardinality, allowed duplication and reference-table update handling. Broadcast join only when small side and memory fit; use AQE where supported/tested.
- For SQL query engines, identify pushdown, federation network costs, partition pruning and file layout before scaling compute.

## C. Stream processing correctness contract
Specify for every job:
1. Source topic(s), key, partition distribution and offset/start position.
2. Event time vs ingestion/processing time; timezone and timestamps.
3. Watermark strategy; allowed lateness; discarded/corrected late-event behavior.
4. Window type (tumbling/sliding/session), size, trigger and retractions/updates.
5. State structures, TTL, cardinality, growth and checkpoint/storage configuration.
6. Dedup key and retention; ordering expectations; missing and duplicate event behavior.
7. Join semantics and reference-data changes (temporal/as-of joins if required).
8. Sink guarantee: idempotent upsert, transactional commit, versioned output or deduplicated materialization.
9. Failure replay: source history available? consistent state and output? restore behavior?
10. Backpressure and end-to-end latency SLIs, spare throughput for backlog catch-up.

### Event time worked example
Events for device D17: (10:02, 300 W), (10:01, 350 W), (10:09, 250 W). If business asks maximum power 10:00–10:10, output 350 W after allowed late-event handling. Do not assume arrival order equals timestamp order; one event arriving after the watermark may need side output/recalculation according to contract.

### Stateful aggregate under replay
After C1 checkpoint stored `count=2, next_input_offset=102`, processed 2 more events and crashed. Restore state and offset together, replay the 2 events → correct logical count 4. The sink may still have seen prior effects: end-to-end exactly-once requires compatible sink behavior; checkpoint exactly-once state isn't automatically exactly-once external output.

## D. Spark-specific implementation guidance
- DataFrame/SQL API preferred for structured data; be aware of lazy evaluation, actions triggering jobs, execution plans and shuffles.
- `spark.read.parquet(...).filter(...)` supports pruning/pushdown when storage layout permits; avoid early collect/toPandas of large data.
- Reuse/caching only if repeated computation justifies memory and cache invalidation; `unpersist` when no longer needed.
- SQL windows for analytics vs streaming windows are different concepts.
- Spark Structured Streaming must define checkpoint persistence, trigger and output mode semantics; `foreachBatch` output must be idempotent for retried batch IDs.
- Performance inspect `.explain()` and Spark UI, stage skew, shuffle read/write, fetch waits, spill, GC, task parallelism.

## E. Flink-specific implementation guidance
- Distinguish session/application deployment, JobManager and TaskManager; starting cluster != submitting job.
- Checkpoint storage must be durable and accessible; checkpoints/savepoints have different lifecycle roles.
- Set time semantics and watermarks deliberately; state and timers can grow without TTL/compaction strategy.
- Backpressure commonly propagates from slow downstream sinks to upstream sources. Investigate busy/backpressured/idle metrics; scaling upstream may worsen sink overload.
- Sink connector version and DB table semantics determine whether consistent output is possible; test restart after external write but before progress acknowledgment.

## F. Idempotent batch and backfill
- Define batch partition/window, source snapshot/watermark, target merge key and deterministic computation.
- For daily partition replacement, use transactional delete+insert / atomic table partition overwrite where supported, or staging then atomic swap; verify no duplicate grain rows and counts/totals. Keep late-arrival correction and audit.
- Airflow retries and dbt incremental models require idempotent targets; DAG success is not evidence data is complete.
- If adding model-based risk scores, keep model version, feature version, inputs/time and confidence/validation. Domain-specific risky decisions need human governance and validation.

## G. Capacity and acceptance
Test average and peak ingestion, end-to-end freshness p95/p99, multi-minute burst, one-hour interruption/recovery, worst hot-key and actual sink batch behavior. Validate **throughput with checkpointing/observability enabled**, not optimized bare engine benchmarks.
