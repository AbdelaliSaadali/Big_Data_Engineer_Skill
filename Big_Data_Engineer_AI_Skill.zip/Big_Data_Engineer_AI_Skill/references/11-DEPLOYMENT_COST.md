# Running data technologies, sizing, scaling and total cost

**Curriculum grounding:** 24.01 How Data Technologies Run, 04 distributed systems, 25 performance, 26 reliability, 27 architecture; 28.01 selection playbook in conversation informs TCO/ADR methodology.

## A. Distinguish what is deployed
- A **client library** lets an application communicate with a service; pip installing Kafka client does not start brokers.
- A **process** is a running program; a **service** typically runs for ongoing requests; a **job** is a defined workload (may be continuous); a **cluster** contains cooperating processes/machines.
- Kafka brokers, Flink JobManager/TaskManagers, Spark driver/executors, PostgreSQL DB server, Airflow scheduler/workers/webserver and EMQX brokers have different runtime needs.
- Native install and Docker run the actual software; containerization packages runtime dependencies; Kubernetes schedules/manages Pods, not application data guarantees.
- Docker Compose is pragmatic for local integration; managed services trade provider dependence and recurring cost for less operational maintenance.

## B. Choose deployment approach
| Scale / constraints | Evaluate first | Caveats |
|---|---|---|
| Small single-machine prototype | Python/SQL + DB / Docker Compose | stateful volumes, container-localhost networking |
| Production small service | managed DB + appropriate app runtime / VM | backup, permissions, runbooks |
| Multi-node stream engine | managed processing/Kubernetes/standalone cluster | checkpoint durability and sink design |
| Self-managed Kafka cluster | containers/VMs/K8s with operator where suitable | broker identity, quorum, storage, operational knowledge |
| Occasional large batch | managed/serverless Spark/warehouse | startup, data movement, costs |

Do not assume Docker creates CPU/RAM or guarantees disk persistence. Container local `localhost` refers to that network namespace; use network service names/advertised listeners correctly. Volumes alone aren't independent backups.

## C. Capacity equations
```
mean_rps = sources * emissions_per_source_per_sec
peak_rps = mean_rps * measured_or_agreed_peak_factor
logical_storage/day = mean_rps * average_payload_bytes * 86400
storage_cost ≈ usable_bytes × time × unit price + request/egress/backup/replica charges
backlog_growth = ingress_rps - processing_rps  (when >0)
catch_up_seconds = backlog / (processing_rps_after_recovery - live_ingress_rps)
```
Model actual compression and retention by layer; don't assume unlimited horizontal scaling. For Kafka one consumer group of 9 consumers on a 6-partition topic has at most 6 actively assigned consumers for that topic. Spark skew can leave executors idle, Flink sink DB might cap throughput, PostgreSQL scaling uses different techniques for writes vs reads.

## D. Cost / TCO decision record
| Cost category | Capture |
|---|---|
| Infrastructure | VM/CPU/RAM, container/K8s control plane, service pricing, storage tiers |
| Data movement | egress, inter-zone/region traffic, object retrieval, connector charges |
| Durability | replicas, snapshots, archive, recovery standby and restore drills |
| Operations | upgrades, alerts, on-call, maintenance, incidents, compliance |
| People | team's skill, development time, hiring/training, opportunity cost |
| Lifecycle | migration, schema evolution, license, exit, vendor lock-in |

Use realistic expected volume and time horizon (e.g. 12/24 months). Distinguish vendor quote from sample math and include unit assumptions. Open data formats help with some migration risks but not necessarily catalog, API or infrastructure portability.

## E. Deployment release safety
- Reproducible images/versions, immutable build artifacts, secrets at runtime, schema migration ordering, health/readiness checks, resource requests/limits and least privilege.
- Multi-service connectivity test using DNS and auth, not just healthy containers.
- Data state separated and backed up; compatible checkpoint paths and source retention across updates.
- Gradual rollouts/blue-green only where state compatibility and writing authority are thought through.
- Provision observability, SLO, quality checks and rollback before launch.

## F. Operational owner matrix
For each component specify: owner/on-call, incident severity, config path, data persistence, backup/replay source, dashboard, runbook, upgrade policy, access grants and monthly cost. If no team can operate a component, a managed alternative or simpler architecture may be more suitable.
