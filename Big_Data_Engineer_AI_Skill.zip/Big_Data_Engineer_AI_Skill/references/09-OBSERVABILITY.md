# Observability, pipeline SLIs/SLOs and incident investigation

**Curriculum grounding:** 23.01 Data Observability; 20 Data Quality; 25 Performance Engineering. Operational signal mapping here is synthesized from these notes.

## A. Three signals and owners
- **Logs**: timestamped structured events with service, severity, correlation/trace ID, pipeline/job ID, error code; redact sensitive data. ELK = Elasticsearch + Logstash + Kibana; Elastic Agent/Beats/Logstash are ingestion tools and Logstash is optional.
- **Metrics**: counters (processed/failed events), gauges (queue depth, lag, task state), histograms (request and ingestion latency), uptime/resource usage. Prometheus stores/scrapes metrics; prevent explosive high-cardinality labels such as raw user/event IDs.
- **Traces**: linked spans across API/broker/processing/DB where instrumentation/propagation supports it. OpenTelemetry supplies instrumentation and collectors, **not a durable telemetry database**. Grafana renders from sources like Prometheus, Loki, Tempo, Elasticsearch.

## B. Monitor both infrastructure and data results
| Stage | Control-plane health | Data-plane/data quality SLI |
|---|---|---|
| MQTT / API | connections, errors, availability | device coverage, accepted/invalid ratio |
| Kafka | broker/replica health, ISR | producer/consumer rate, lag per partition, age of newest processed event |
| Flink | restarts, checkpoint health, busy/backpressured time | processed events/s, event-time delay, drop/retract count |
| Spark/Airflow | DAG/task status, executor resources | expected partitions, rows, duration vs baseline, completeness |
| PostgreSQL/ClickHouse | connection/CPU/I/O/query errors | query p95/p99, ingest rate, freshness, valid grain count |
| Warehouse/BI | scheduled runs, credits and errors | publication freshness, KPI consistency, dashboard query latency |

## C. Freshness math
For `now=10:20`, last_ingested_at=`10:19`, last_event_time=`10:05`:
- ingestion freshness age = 1 minute;
- event freshness age = 15 minutes.
These are different! The latest global record can hide a single device/site stale for hours. Report per key/source coverage as required; event clocks require validation and drift allowances. Dataset publication freshness may differ from record ingested/event time.

## D. SLI/SLO specification
Define numerator, denominator, observation window, exclusions and alert condition:
```
SLI: count(valid events visible in serving table <=10s after broker receipt)
     / count(all eligible events broker-accepted in window)
SLO: >=99.5% of eligible events in trailing 24h
Dependencies: clock skew, late input, observation horizon and dedup definitions
```
An error budget is allowed misses over the chosen window; e.g. 10k eligible events, 99.5% target → 50 misses allowed. If 130 late, budget consumption = 130/50 = 260%. Confirm business definition before implementing.

## E. Practical dashboards and alerts
- Golden signals for each service: traffic, errors, latency and saturation; pipeline-specific: freshness, input vs output throughput, per-partition Kafka lag, Flink backpressure/checkpoints, batch durations, quality reject/duplicate counts and source coverage.
- Prefer alerts with specific owners and actions: missing input from critical cohort >X, SLO burn, sustained Kafka lag growth, checkpoint failure, warehouse data stale after publish deadline. Avoid static CPU-alert-only ops.
- Handle low traffic and absent time series as distinct from healthy state. Alert on `no incoming data` only if expected according to schedule.
- Provide annotation/correlation across deployments, model/schema changes and data quality failures.

## F. Incident response runbook
```
Observe symptom → identify affected consumer / SLO
→ compare ingress/egress rates + timestamps at each boundary
→ examine resource waits/backpressure/DB sink metrics
→ reproduce/confirm cause (evidence in logs/traces/plan)
→ remediate one supported cause using approved procedure
→ verify no missed/duplicated outputs, freshness and SLO recovery
→ record root cause, detection and prevention
```
Kafka lag growth is often a **symptom** of a slow Flink sink or hot partition; Flink busy/backpressure percentages alone are hints, not proof. Do not pretend monitoring means no data loss; perform reconciliation.

## G. Evidence package
For any outage report include: timeline, affected sources/consumers, first bad boundary, deployment/change history, resource and pipeline metrics, tested hypothesis, action, source-output reconciliation, data restored, RPO/RTO if relevant, follow-ups and confidence/remaining unknowns.
