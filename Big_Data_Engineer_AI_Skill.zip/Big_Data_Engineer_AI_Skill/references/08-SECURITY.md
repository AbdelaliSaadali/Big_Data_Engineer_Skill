# Security for every data-system component

**Curriculum grounding:** 22.01 Data Security Fundamentals; 21 governance and lifecycle; 24 cloud deployment. Specific cloud IAM and encryption semantics vary by provider; validate against current official docs.

## A. Threat model before product settings
Map: actors/services, assets (raw PII, event streams, BI datasets, credentials, model features), entry points (API/MQTT/DB connector/warehouse), trust boundaries, likely misuse/failure, controls and audit evidence. State whose data is accessed and why; minimize access and copied data.

## B. Mandatory controls
| Layer | Baseline controls | Verify |
|---|---|---|
| Identity | unique machine/workload identities, no shared hard-coded credentials | role mapping / rotation |
| Authentication | API auth, MQTT identity/cert as suitable, managed IAM | unauthorized attempts rejected |
| Authorization | least privilege, RBAC/ABAC or ACL, tenant/site row constraints | negative tests across tenants |
| Transport | TLS/mTLS as appropriate, secure broker listeners, private access | cipher/config/network tests |
| At rest | encryption and KMS policies where required | key permissions/restore |
| Secrets | secret manager/env injection, limited exposure, rotation | repo/log secret scan |
| Network | segmentation, allowlist ingress/egress, private endpoints | connectivity map |
| Data | classification, masking/tokenization, retention/deletion | sample views and requests |
| Audit | access/admin events, correlation and tamper-aware retention | audit query |
| Operations | secure CI/CD, container image/dependency scans, incident response | deploy artifacts / evidence |

IAM rule: distinguish identity authentication from authorization. Data-layer access must not depend solely on a trusted front end. If BI consumers are multi-tenant, apply row-level and/or column-level security in the serving layer where supported, test by different roles.

## C. Cross-component credential flow
```
Device (per-device identity) --TLS--> MQTT broker
  broker integration role --restricted auth--> streaming log
  Flink workload role --topic-read/secret-store--> DB sink
  BI service account --read-only curated views--> dashboard
```
No single shared superuser token. Plan topic ACLs, column masks, DB grants, object bucket policies and catalog permissions coherently. Encrypt backups and ensure restore roles can access keys under disaster conditions.

## D. Sensitive data and minimization
- Raw telemetry may reveal behavior; location, identifying signals or health-risk outputs may be highly sensitive. Classify based on actual data/context, not simply field type.
- Enforce minimum collection, purpose-limited usage, retention, restricted viewing, safe logs and test fixtures using synthetic/nonidentifying examples.
- For models producing risk classifications, document version, evaluation limitations, adverse impact, authorized users and human escalation. Do not treat an ML score as clinically authoritative based solely on pipeline validity.
- Avoid transferring real sensitive records into third-party prompts or dev fixtures without authorization; do not print credentials or sample production payloads in troubleshooting output.

## E. Security review gates
1. Data map and classification per zone.
2. Identity and permission matrix for every actor and service.
3. Source ↔ broker ↔ processing ↔ storage ↔ BI network flows.
4. Key management, secret rotation and break-glass/DR access.
5. Audit, breach detection, error logs without sensitive payloads.
6. Restore and deletion process with data lifecycle policy.
7. Compliance requirements verified with organizational policy; don't claim GDPR/HIPAA/etc. compliance simply from encryption settings.

## F. Safety in AI-assisted implementation
Never run destructive production commands or grant broad permissions without explicit approval and a reviewed plan. Prefer `SELECT`, `EXPLAIN`, dry-run, staging, backups, least-privilege migrations and parameterized statements. Do not ask users to paste secrets into chat; support environment variables/secret managers and redacted config examples.
