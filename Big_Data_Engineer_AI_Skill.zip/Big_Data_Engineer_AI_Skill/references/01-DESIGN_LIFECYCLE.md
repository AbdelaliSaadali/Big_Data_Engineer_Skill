# Design lifecycle: requirements → workload → architecture → selection → evidence

**Curriculum grounding:** 01.01 Data Fundamentals & Workload Vocabulary; 27.01 Architecture Patterns & How to Design a Data System; 24–26 operations and recovery. **Skill additions:** decision-card, explicit assumption register, ADR/POC stage gates (28.01 conversation playbook).

## A. Intake without premature tools
Capture the business outcome in one sentence, user personas, producers, consumers, source system of record, required outputs and ownership. Separate *functional* requirements (e.g. show daily energy by site) from measurable *non-functional* requirements (e.g. valid observations available by 09:00 each day). Ask for hard constraints: deployment/network boundaries, data residency, team, languages, licensing, cost ceiling, retention and criticality. When unspecified, mark assumptions and propose a small baseline rather than interrogate endlessly.

Capture:
| Requirement | Example | Verification |
|---|---|---|
| Sources | PostgreSQL orders + MQTT telemetry | sample data, protocol docs |
| Logical event | immutable `event_id` per source event | source contract |
| Average / peak | 100/s, 1000/s, 1 KB/event | source counters |
| Freshness | p99 events visible within 10s of broker receipt | ingest/write timestamp query |
| Throughput | sustained peak 1000/s for 1 hour | load test |
| Recovery | RPO 5m, RTO 30m for loss of primary | restore drill |
| Semantics | no incorrect duplicate invoice totals | reconcile source/output |
| Retention | 30d hot / 2y approved aggregates | storage lifecycle query |
| Security | site-scoped records; TLS; encrypted storage | auth/security tests |

## B. Calculate and avoid misleading quantities
- `events/sec = producers × events per producer/sec`. Device count alone never proves Kafka necessary.
- `raw_bytes_per_day = events/sec × payload_bytes × 86400`. Distinguish bytes from MB/GB (decimal vs binary), protocol headers, partition metadata, indexes, replication, storage format compression, checksums, backups, retention and egress.
- `logical_data_for_retention ≈ raw_bytes_per_day × retention_days` before compression/amplification. For cloud costs, separately estimate hot storage, archive retrieval, requests, compute, replicas and backups.
- `backlog_growth = incoming_records/s − effective_processing_records/s` if positive. If processing is restored, `catch_up = accumulated_backlog / (processing_capacity − live_input)` **only if processing_capacity > live_input**.
- p99 ≠ average; event freshness may differ from ingestion freshness; SLA ≠ SLO.
- Capacity must accommodate failure/recovery as well as normal load.
- Quantify cardinality of partition keys, joins, labels and dimensions; estimate worst-case hot-key distribution.

## C. Draw logical architecture first
Required source-to-serving contract:
```
Producer / source of truth
   → Capture [API, CDC, file, MQTT]
   → (Durable messaging only if needed)
   → Processing [batch / continuous / SQL]
   → Storage [operational / historical / analytical]
   → Semantic serving [API, BI, ML features]

Parallel concerns: schema registry/data contract, IAM, quality, metadata/lineage,
                   audit, observability, replay, backup, cost budget.
```
Label which pieces are *existing*, *proposed*, *optional* or *future*. Draw explicit direct-route alternatives, not mandatory Kafka-to-Flink pipelines. Distinguish data-plane and control-plane flows (e.g., Airflow schedules tasks but isn't inherently a location where payload data flows). State which component owns truth and how replicas/caches are invalidated.

## D. Processing/architecture choice
| Workload driver | Usually evaluate first | Architecture caveat |
|---|---|---|
| Small periodic CSV/API intake | Python + SQL + scheduler | No distributed engine required |
| Large bounded scan/aggregation | Warehouse SQL, Spark | Consider data movement/cost |
| Continuous stateless filtering | Existing service, SQL stream or Flink only if needed | Simplicity often wins |
| Stateful event-time windows / keyed enrichment | Flink, Spark Structured Streaming | Plan watermark, state TTL, recovery |
| Shared replayable event log | Kafka/Pulsar/managed equivalent | Complexity, retention and partitioning |
| Live and historical views | Separate consumers or hybrid | Lambda dual logic only when justified |
| Unified replayable processing | Kappa-like stream path | Archive/replay compatibility required |
| Refined analytical data products | Bronze/Silver/Gold | Logical layers not necessarily separate systems |
| Multiple organizational data domains | Data mesh principles | Governance/ownership change, not installable product |

## E. Two-stage technology decision procedure
1. Define mandatory capabilities with testable proof; eliminate any candidate architecture failing them. Include “reuse existing database/service” among options.
2. Shortlist 2–3 viable architectures per major choice. Compare throughput/latency *under representative workload*, correctness, operational effort, data movement, TCO, security posture, portability, ecosystem, team expertise and migration strategy. Use weighted scores only for qualified candidates; do not allow a score to overrule a mandatory requirement. Record uncertainty ranges.
3. Run a focused POC that answers the riskiest unknowns (e.g., catch-up after sink outage, SQL p99 for actual filters, SCD2 late correction, replay no duplicates), not a polished demo.
4. Document an ADR containing reasons, rejected alternatives, observed results, risks, assumptions and revisit triggers.

## F. Stage gates
- **Gate 1 design**: clear owners, business metric definitions, workload estimate, sources/consumers, architecture diagram, schema/key/grain, failure boundaries, acceptance tests.
- **Gate 2 proof**: minimal pipeline on representative sample including invalid, duplicate, late and correction records; core tests passing.
- **Gate 3 preprod**: representative peak, monitoring, safe migration, backup/restore, access validation, cost projection.
- **Gate 4 operating**: runbooks, dashboards, incident routing, quality exceptions, change management, data catalog and periodic review.

## G. Response mode guidance
- Architecture: provide diagram + alternatives + data model + failure story + tests and unresolved decisions.
- Coding: provide file tree, runnable code and setup instructions, tests with input/expected output; never use fake test results.
- Troubleshooting: reproduce, measure, isolate, hypothesize, change one thing, verify; do not propose unrelated refactoring.
- Migration: current/target contracts, dual-run plan, reconciliation, rollback and deprecation.
- Technology choice: concrete conditions and constraints, not universal “X is always better” claims.

Use templates `PROJECT_INTAKE.md`, `TECHNOLOGY_EVALUATION.md`, `ADR.md`.
