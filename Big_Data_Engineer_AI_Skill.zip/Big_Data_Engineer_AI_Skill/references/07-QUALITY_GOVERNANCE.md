# Data quality, governance, catalogs, metadata, lineage and lifecycle

**Curriculum grounding:** 20.01 Data Quality Engineering; 21.01 Governance, Metadata, Catalogs & Data Lifecycle; 19.01 metrics; 15–18 data flow. The operational templates are synthesis of this material.

## A. Data quality dimensions as executable contracts
| Dimension | Example control | Failure action |
|---|---|---|
| Completeness | expected device/day coverage / required non-null | flag stale/incomplete partition |
| Validity | power_w numeric and in plausible agreed range | reject/quarantine; never silently coerce |
| Uniqueness | `(source, event_id)` exactly one logical event | dedup with audited reason |
| Consistency | `payment_total == sum(valid line totals)` | fail publish / investigate |
| Timeliness/freshness | last accepted event within agreed window | mark provisional, alert if SLO breached |
| Accuracy | benchmark against trusted reference / calibration | domain review; cannot infer accuracy from shape |
| Referential integrity | every order_item → valid order | quarantine or batch failure |

Compute and persist row counts at boundaries: received, parsed, accepted, duplicates, rejected, written, served. Invariant for non-filtering pipeline: `received = accepted + quarantined + duplicates` when categories are exclusive and defined. Track correction/update cases separately from inserts so counts remain meaningful.

## B. Data contracts and schema governance
- Contract fields: owner, purpose, schema ID/version, required/optional types, event grain/key, source, time/units, PII class, SLA/freshness, retention, compatibility policy, consumer dependencies and deprecation plan.
- Breaking schema changes require consumer inventory, dual-read/write or rollout, validation, catalog update and explicit approval when critical.
- Quarantine records with reason code, source metadata and safe redaction; define who may inspect and how to replay after fix.
- SLA/SLO/data quality alert thresholds need baseline and actionable owners; avoid arbitrary “100% all fields not null” requirements.
- For data domains with automatic decisions, explicitly document whether quality faults cause drop, retry, hold, compensate or human review.

## C. Metadata taxonomy
- Technical: schema, types, storage, partitions, row counts, format, source, freshness, pipeline run IDs.
- Business: dataset meaning, owners/stewards, business glossary, KPIs, approved usage and classifications.
- Operational: run times, job statuses, errors, resource cost, SLO and retention metadata.
- Lineage: source-to-target dataset and column-level transformations, job dependencies, transformations, source code refs, impact analysis.

Metadata should be discoverable via a catalog where scale justifies it (e.g. DataHub, OpenMetadata, Apache Atlas). A catalog is not identical to a storage backend or query engine. OpenLineage-like events can populate lineage; validate connector coverage. Do not assert lineage is complete if some manual transformations are missing.

## D. Build lineage from a transformation
Example:
```
PostgreSQL.orders.id, status, ordered_at
   └─ CDC → kafka.orders_change
              └─ stg_orders.sql → silver.orders
                    └─ fct_paid_orders.sql → gold.fct_paid_orders
                          └─ metric paid_order_count → BI dashboard
```
Column dependency: `paid_order_count` depends on `orders.status`, `orders.id`, filtering rules and distinct grain. Changing status semantics may impact dashboards; map from consumer back to source. Annotate dataset/column lineage and job/version.

## E. Stewardship and lifecycle
For each dataset: data owner, steward, technical maintainer, purpose, legal/compliance classification when applicable, retention by zone, disposal method, backup retention, deletion propagation through derived outputs and caches, and approved access groups. Define response path for access/deletion/correction requests; do not invent legal deadlines. Sensitive subject data needs heightened care and explicit policy verification.

## F. Data product readiness checklist
- Clear consumer/business problem; schema/grain and meaning documented.
- Accessible through defined interface (SQL/API/file/event) and versioning.
- Owner/on-call and support path published.
- Quality/freshness tests and expectation thresholds operational.
- Access, classification and permitted uses enforced.
- Lineage and reproducibility demonstrated for critical outputs.
- Recovery/correction/rebuild plan; backward-compatible evolution.

## G. Common traps
- Dashboard running isn't proof latest data is published.
- A great chart can mask missing devices / populations; monitor subgroup coverage rather than only global freshness.
- A data catalog full of metadata but no ownership is not governance.
- SCD2 lineage must include effective-time semantics, not only table arrows.
- Source retention/deletion cannot be bypassed by keeping unwanted copies in backups, archives or ML caches without approved policies.
