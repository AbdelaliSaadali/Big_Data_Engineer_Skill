# Architecture recipes: conditions, evidence, alternatives and failure stories

**Curriculum grounding:** 10 messaging, 11 processing, 12–14 analytics stores, 15–18 transformation/CDC/orchestration, 20–26 cross-cutting engineering, 27.01 architecture patterns. These are **illustrative proposals**; no recipe is an established deployment or an automatic one-size-fits-all prescription.

## Recipe 1 — Small IoT monitoring without overengineering
**Assume:** ~200 MQTT devices, 1 event/30s, one backend, dashboard updates within 10s, 30d history, one modest server.
```
Device → EMQX → FastAPI ingestion → InfluxDB telemetry → dashboard
                            └────→ PostgreSQL metadata/device registry
```
- Model `device(device_id, site_id, status, ...)`, `telemetry(event_id, device_id, event_time, ingested_at, power_w)` and site-scoped authorization. Use TSDB when query patterns truly warrant it; Postgres/Timescale may suffice instead of two DBs.
- MQTT QoS/session/device offline buffer boundary; stable event IDs/duplicate handling; expected vs received coverage; timestamp clock drift; retention, backups and restores.
- **Reject for now** Kafka/Flink/Kubernetes unless replay, many independent consumers, stateful event-time processing or multi-node ops needs emerge.
- Tests: sudden reconnect burst, duplicate event, invalid payload, missing device for 15min, DB unavailable, p99 freshness, owner/tenant access, recovery.

## Recipe 2 — SentriSign extended analytics (proposed)
**Known curriculum project context:** Shelly IoT → MQTT/EMQX, PostgreSQL device metadata, InfluxDB telemetry, FastAPI/backend/frontend supervision. **Optional extensions below are NOT existing deployment facts.**
```
Shelly → EMQX → existing backend/InﬂuxDB
              └─ [PROPOSED MQTT–Kafka bridge] → Kafka telemetry
                                     ├→ Flink alert/features → OLAP (optional)
                                     └→ object storage Parquet/Iceberg → SQL/dbt → BI
```
Only propose after specifying incremental needs. Verify device power vs energy conversion, per-device completeness, timezones, data grain, source ID and bridge ack/duplicate semantics. For master project avoid duplicating storage without a business use case and cost model.

## Recipe 3 — RaqibCare stream analytics (education / proposed changes)
**Curriculum chain:** mobile sensors → FastAPI → Kafka → Flink → feature extraction → AI risk engine → ClickHouse/PostgreSQL → Grafana/alerts. Validate actual implementation. Any archive/cloud scale is illustrative.
```
Mobile → authenticated FastAPI → Kafka source
                                   ├→ Flink stateful event time + feature logic
                                   │      └→ risk model (versioned, validated) → serving output
                                   └→ [optional long-term immutable archive]
```
- Specify event schema/unit/times, session/window semantics, consent/access policy, dedup, model input contract and audit of model/feature versions.
- Build end-to-end failure matrix: API accepted before Kafka ack, Flink checkpoint vs sink commit, retention lost before replay, model error, DB unavailable, recovery and data reconciliation.
- Domain-sensitive risk outcomes require careful validation, privacy restrictions and human oversight; data pipeline success is not proof of clinical reliability.

## Recipe 4 — E-commerce OLTP to analytics
**Assume:** orders/products/payments in Postgres, BI wants hourly revenue/order facts; sources updated frequently.
```
PostgreSQL OLTP (orders/order_items/payments)
  ├─ direct app transactions
  └─ CDC (Debezium) / transactional outbox → event log (if justified)
        → landing (raw before/after/delete, source tx position)
        → staging + SCD dimensions → fct_order_item + payment facts
        → approved revenue metric → BI
```
- Distinguish payment authorized/settled/refunded; avoid double counting items × payments joins. One fact row per order item; monetary decimal with currency, tax, discounts; SCD2 customer/product attributes only if historical-as-of analytics needed.
- Source snapshot/log catch-up, deletes, replays, upsert key, reconciliation by day/source ID, currency and as-of semantics; share dashboard metric definition.
- If hourly daily extracts sufficient, scheduled SQL/ELT may be simpler than CDC/Kafka.

## Recipe 5 — Warehouse and lakehouse batch analytics
**Assume:** several APIs/CSV/database sources, nightly transformation, modest freshness SLA.
```
Sources → Python/connectors → object storage/raw landing or staging DB
      → incremental warehouse/lakehouse tables → SQL/dbt staging/joins
      → facts/dims/gold marts → BI semantic layer
               Airflow controls schedules, data-quality gates, backfill
```
- Source manifest & fetch watermark, schema contract, transactional table update, partition boundaries, dedup and historical correction handling.
- Choose warehouse vs open table format on object storage from performance, concurrency, governance, team, catalog compatibility and cost. Consider one engine rather than Spark + Trino + warehouse without workload evidence.
- Test late-file arrivals, API pagination 429, malformed CSV, partial DAG failure, schema changes, cost of historical recompute, transactional publication and BI permissions.

## Recipe 6 — Centralized log analytics
**Assume:** applications emit structured errors and request traces, ops need 14d searchable log retention.
```
Apps / containers → collectors (Elastic Agent/Fluent Bit/etc.) → Elasticsearch/OpenSearch
                                                          └→ Kibana-like log UI
Apps / exporters → Prometheus metrics → Grafana dashboards and alerts
OTel instrumentation/collector → trace backend (e.g., Tempo) → Grafana
```
Logstash optional parsing route. Define correlation IDs, redaction, hot/warm retention, shard/index growth, high-cardinality restrictions, actionable SLOs. Don't route all business records into log index as permanent system of record. Add Kafka only if buffering/replay needs justify.

## Recipe 7 — Fraud-signal / operational anomaly scoring (conceptual)
**Assume:** event decisions under a defined p99 deadline; event histories and account profiles required.
```
Transaction service (authoritative write) → event/command boundary
    → stream processing keyed by account (windowed velocity features)
    → versioned risk evaluation → verified action/alert interface
    → historical audit and replayable input/archive
```
Clarify whether decision must block a synchronous transaction or is asynchronous post-event alert. A Kafka+Flink route is not a guarantee of <200ms synchronized authorization; measure end-to-end p99 and service fail-open/fail-closed behavior with business stakeholders. Label flagged outcomes as signals requiring policy and error analysis, not perfect fraud detection. Support data security and traceability.

## Recipe 8 — Migrating from simple to distributed
Trigger: rising query/backlog SLO breaches, many independent consumers, source replay requirement or ops constraint. Sequence:
1. Measure current pipeline; identify bottleneck/correctness need.
2. Define immutable source IDs/contracts and isolate capture/serving interfaces.
3. Introduce new component in shadow mode (e.g., Kafka bridge) without altering source truth.
4. Dual-run and compare counts, event IDs, freshness and metrics across representative historical/peak windows.
5. Cut over by controlled consumer group/route; hold rollback and data replay plan.
6. Remove obsolete components only after data and access checks.

## Universal decision checklist
For every recipe record: `why each component`, alternative without it, data contracts and grain, partitioning/keying, failure and idempotency boundary, late updates/deletes, quality/quarantine, classification/IAM, catalog/lineage, logs/metrics/traces, SLO, retention/RPO/RTO, cost, benchmark, ADR and owner. Anything not demonstrated is a proposed design, not a measured capability.
