# Data modeling, schemas, temporal semantics and metrics

**Curriculum grounding:** 02 SQL & Relational, 03 Operational/Analytical Data Modeling, 19 Analytics & BI, 20 Data Quality, 21 Metadata. Read original 03.01 and 03.02 for full ER/SCD examples.

## A. Start with business process and query patterns
For every dataset identify: entity/business event, **grain** (exactly what one row means), unique identifier, natural/business key, relationship/cardinality, expected queries, write/update patterns, time semantics, lifecycle and owner. If ambiguous, do NOT draft SQL as if grain were known. Explicitly distinguish source-of-truth operational records from derived analytical facts.

## B. Operational/OLTP model
- Derive entities from business concepts, relationships 1:1, 1:N, N:M using junction tables with meaningful composite keys.
- Use PK/UK/FK/CHECK/NOT NULL to express actual invariants; avoid placing JSON everywhere merely to avoid modeling. Prefer 3NF as a starting point for update-heavy OLTP; selectively denormalize with known justification.
- Keep IDs stable. Model tenant/site segregation as first-class keys and access policy; never trust app-side filtering as the sole cross-tenant boundary.
- Use appropriate types: `DECIMAL/NUMERIC` for money; `TIMESTAMPTZ` for instants where supported; integer/UUID/text IDs according to source; explicit units; controlled enum/reference tables; avoid floating point for accounting.
- Model status transitions and timestamps (`created_at`, `updated_at`) and whether soft deletion/audit history is required.
- DDL migrations must be reversible or have controlled roll-forward plan; index selection follows query predicates and write load, not every column.

Example PostgreSQL transactional model:
```sql
CREATE TABLE customers (
  customer_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  email text NOT NULL UNIQUE
);
CREATE TABLE orders (
  order_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  customer_id bigint NOT NULL REFERENCES customers(customer_id),
  ordered_at timestamptz NOT NULL,
  currency char(3) NOT NULL,
  status text NOT NULL CHECK (status IN ('pending','paid','cancelled'))
);
CREATE TABLE order_items (
  order_id bigint NOT NULL REFERENCES orders(order_id),
  line_no integer NOT NULL CHECK (line_no > 0),
  product_id bigint NOT NULL,
  qty integer NOT NULL CHECK (qty > 0),
  unit_price numeric(18,2) NOT NULL CHECK (unit_price >= 0),
  PRIMARY KEY (order_id, line_no)
);
```
Adjust money, tax, currency, inventory and ID specifics to actual domain rather than calling this production-complete.

## C. Analytical OLAP model
- Before schema, state fact **grain**, measure types (additive/semi-additive/non-additive) and metric definitions, dimension keys, temporal joins and late corrections.
- Example: `fact_order_item` = one row per purchased line item with order_id+line_no degenerate keys; dimensions: date, product, customer, channel. Do not aggregate distinct order count by summing line-level counts.
- Star schema often simpler for BI; snowflaking/denormalization are workload trade-offs. The storage engine may choose columnar or aggregate stores; conceptual model is independent.
- Prefer conformed dimensions for consistent analytics; document source of truth, timezone/currency conversion and filters for every metric.
- SCD Type 1: overwrite corrections where historical dimension changes are irrelevant; Type 2: version dimension rows with surrogate key and `valid_from`/`valid_to`, ensuring nonoverlapping validity for a natural key. Define boundary inclusion; recompute fact-to-dimension mapping for late records if required.

Example:
```text
fact_sensor_interval grain: one validated non-overlapping interval per device/event_id
keys: event_id UNIQUE, device_key, site_key, date_key
measures: avg_power_w (W), interval_seconds (s), energy_kwh = power_w*seconds/3600000
semantics: constant/representative power over interval — domain assumption to verify
```
Never sum instantaneous power readings to claim energy without integrating over time. For rates, averages and percentages, define denominators and weighting. `AVG(AVG())` can be wrong when groups have unequal counts.

## D. Event model and time
A robust event contract includes `event_id`, `schema_version`, `producer/source`, `entity/device_id`, `event_time`, `ingested_at` as needed, payload, units and optional correlation/trace ID. Distinguish event happened, broker received, processed, landed, published and business effective times. UTC instants for interchange; retain explicit local-time/business-calendar semantics separately.
- Preserve immutable original event ID across retries; if upstream IDs unreliable, declare dedup scope and collision risk.
- Ordering within a Kafka partition ≠ global event-time order. Define keying and watermark/allowed-lateness policy.
- CDC events have transaction/operation order and snapshot phases; distinguish delete/update/before/after semantics.
- Schema evolution: backwards/forwards compatibility depends on readers/writers; defaultable optional fields and field renames need migration plans. Schema registry may be justified for widely shared contracts.

Example event envelope:
```json
{
  "event_id":"dev17-000123",
  "schema_version":1,
  "device_id":"D17",
  "event_time":"2026-10-17T10:00:00Z",
  "measurement":{"power_w":310.0},
  "source":"shelly-gateway"
}
```
This envelope is illustrative; don't claim it matches an actual device payload.

## E. Modeling validation checklist
- ER diagram and star/grain statements agree with SQL and sample records.
- Every table has owner, purpose, primary/natural/business keys, relationships and lifecycle.
- Every measure has definition, grain, units, aggregation validity, null policy and allowed filter context.
- Confirm join keys/cardinality and prevent fanout multiplication; compare pre/post join record and distinct key counts.
- State how inserts, updates, hard/soft deletes, backfills, late records and retention affect tables.
- Add referential tests, uniqueness, not-null, ranges, accepted values and temporal validity checks.
- For CDC or replay, stable upsert/merge keys and reprocessing boundaries are non-optional.

## F. Frequent model mistakes
- Fact table mixes order and order-item grains; revenue multiplied by accidental fanout.
- SCD2 temporal join not constrained by effective period; revenue appears multiple times.
- Using `FLOAT` for money; strings for all timestamps; mixing W/kW/kWh; `AVG` of group averages without weighting.
- Treating deduplication by timestamp as safe without event ID semantics.
- Designing NoSQL partition keys before query patterns; designing OLTP around dashboard queries only.
- No unique source event key; cannot safely replay or reconcile.
