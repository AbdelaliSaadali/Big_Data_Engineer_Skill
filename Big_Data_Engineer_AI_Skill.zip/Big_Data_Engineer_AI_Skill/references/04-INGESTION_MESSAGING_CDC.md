# Ingestion, data movement, messaging, Kafka, MQTT and CDC

**Curriculum grounding:** 10.01–10.05, 15.01 ETL/ELT integration, 16.01 CDC, 04 distributed partitioning/replication. See original notes for Kafka KRaft, broker ISR and QoS internals.

## A. Distinguish contracts before choosing a broker
| Requirement | Likely category | Critical tests |
|---|---|---|
| Direct API ingest and persist | HTTP/gRPC + database | retries, idempotency, authentication, backpressure |
| MQTT device communication | MQTT broker, e.g. EMQX | QoS, persistent sessions, device buffering, reconnect, will message |
| Discrete asynchronous jobs | Queue e.g. RabbitMQ/SQS | ack, visibility/retry, dead letter, work assignment |
| One event to many independent consumers, replay | Durable log e.g. Kafka/Pulsar | retention, ordering by partition, lag, offsets, consumer independence |
| Changes from DB transaction log | CDC such as Debezium | snapshot consistency, DDL evolution, deletes, outbox |
| Scheduled file/API ingest | Python/ingestion connector + orchestrator | pagination, incremental watermark, 429/retries |

Do not call a task queue an event log. SNS, Event Hubs, Google Pub/Sub, Kinesis, NATS/JetStream and Redis Streams differ in retention, acknowledgment, offsets and scaling: compare guarantees by **specific service/version**. No guaranteed universal exactly-once API-to-warehouse design.

## B. Event ingestion specification
For each edge define:
```
source: MQTT device / PostgreSQL WAL / REST API / file
payload & version: JSON/Avro/etc., sample records
producer identity: device/user/service auth, rate limits
idempotency: stable event_id + dedup scope/TTL
ack boundary: what means "accepted" and when it is durable?
ordering: per device / partition / global? reality of late events?
retry: exponential backoff+jitter, bounded or quarantine; poison message path
retention: hot log and archive duration vs worst recovery requirement
monitor: accepted/s, rejected/s, lag, DLQ, late events, schema errors
```
If source device is offline and never buffers/publishes events, broker-side sessions cannot conjure lost telemetry. MQTT QoS 2 is a protocol boundary, not guaranteed end-to-end exactly-once storage.

## C. Kafka design
- Estimate partitions from **parallelism needs, throughput benchmark and ordering key**, not a fixed rule per X events/s. Producer key decides partition locality; hot keys can dominate a partition.
- Define topics by contracts and consumers, not every application class; clear naming, key/value schema evolution, retention, compaction policy, owner and ACLs.
- Replication factor, `acks`, `min.insync.replicas`, broker health and producer retries determine durability under specific failures; don't promise zero loss without scoped guarantees.
- Consumers commit offsets at meaningful boundaries; `current offset != data processed correctly in sink`. Kafka lag is records/offset distance, not elapsed seconds.
- Exactly-once Kafka transactions cover suitable Kafka workflows; external sinks need compatible transactions/idempotency/reconciliation.
- Kafka Connect and connectors: source/sink throughput, error tolerance, DLQ, converters, schema registration, offset storage, snapshot/backfill consistency.
- For MQTT → Kafka bridge, define mapping of topic/payload IDs and MQTT acknowledgment relative to durable Kafka write; document failures/reconnect/dedup.

## D. CDC and outbox
CDC from DB log preserves row changes (inserts, updates, deletes) but source snapshot and log handoff must align; ingest deletes and schema migrations intentionally. CDC emits physical row-change structure, not automatically business-level event semantics.

Transactional outbox for app business events:
```
BEGIN database transaction
  UPDATE orders SET status='paid' WHERE order_id=:id;
  INSERT INTO outbox(event_id, type, payload, created_at) VALUES (...);
COMMIT
    → CDC or relay → Kafka → idempotent subscribers
```
Recording the business change and outbox row in one DB transaction resolves the "DB committed / Kafka event never recorded" gap. Relay may republish; consumers dedup using immutable event ID. Define cleanup of published outbox entries and operational lag.

## E. API/file ingestion reliability
- APIs: authentication token rotation, pagination, rate limits, partial failures, retries with idempotent pagination checkpoints, schema changes, response snapshot consistency.
- Files: arrival manifests, checksum/size, immutable landing, atomic publication markers, naming/date rules, duplicate-file detection, quarantine.
- Incremental extraction: high-water marks + tie breaker, overlap/lookback windows, soft/hard deletes, timezone and update semantics; avoid naive `WHERE updated_at > last_seen` loss for equal timestamps.

## F. Work the boundary with real examples
Sample `input → operation → output`:
```
MQTT source: {"event_id":"D17-42","device_id":"D17","power_w":310}
validate: device_id exists; value numeric; event_id unique per device
publish: Kafka topic telemetry.raw, key D17, same event_id retained
consume: parse schema, de-duplicate or effect-idempotent write
sink: telemetry table with UNIQUE(event_id) or deterministic upsert
```
Show what happens if API accepts but cannot publish, if message is delivered twice, if consumer crashes after sink commit, if partition key is hot, or if retention expires before recovery. Require source-vs-sink reconciliation over explicit time bounds.
