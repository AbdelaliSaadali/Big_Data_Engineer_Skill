# Full curriculum coverage — what the engineering agent actually applies

This map ensures the agent does **not** narrow "data engineer" to Kafka + Spark. It connects every folder studied to a design decision, implementation task and proof of correctness. Original text is under `knowledge/source_notes/` and exact filename links appear in `references/SOURCE_MAP.md`.

| Notes | Area | Agent should *do* (not repeat theory) | Practical acceptance evidence |
|---|---|---|---|
| 00.01–00.03 | Data field, roles, Big Data scope | Clarify producer, owner, analyst, DBA, data scientist roles; distinguish actual data problem from hype | Business outcome, responsibilities and data-flow map |
| 01.01 | Data/workload vocabulary | Identify schema, volume/velocity/variety, latency, hot/cold paths, bounded vs unbounded workload, OLTP/OLAP | Measured/assumed sizing with units, SLA/Freshness |
| 02.01 | Relational model + SQL | Define PK/FK/NOT NULL/UNIQUE/checks and meaningful SQL access | Migrations and constraint tests |
| 02.02 | Joins, CTEs, windows, aggregates | Ensure correct join cardinality and window/metric math | Correct input→query→output, no fanout |
| 02.03 | Relational internals | Assess B-tree indexes, MVCC/ACID, isolation, WAL and query plans | EXPLAIN/ANALYZE, transaction/recovery behavior |
| 03.01 | Operational modeling | ERD, normalized transactional schema, junctions and lifecycle | Model diagram, constraints, update/delete tests |
| 03.02 | Analytical modeling | Declare fact grain, additive measures, dimensions, conformed dimensions and SCD Type 1/2 | Grain uniqueness, historical-as-of and metric tests |
| 04.01 | Distributed systems | Distinguish machines/nodes/processes, latency/partial failure, horizontal vs vertical scale | Failure-scope and topology diagram |
| 04.02 | Partition/replication/consistency | Choose partition key, replica semantics, allowed inconsistency | Hot-key load test and stated consistency guarantee |
| 04.03 | Coordination and fault tolerance | Plan leader/quorum/failover and avoid split brain | Supported failure and leader election test |
| 05.01 | Physical storage | Compare row/column scans, compression, indexes and read/write patterns | Query profiles and space/IO measurements |
| 05.02 | File formats | Choose CSV/JSON/Avro/Parquet/ORC based on schema/analytics | Evolution, decode and pruning tests |
| 06.01 | Hadoop Core | Identify HDFS/YARN/MapReduce where existing/historical cluster is relevant; avoid prescribing by habit | Existing cluster compatibility and resource constraints |
| 06.02 | Hadoop ecosystem | Evaluate Hive/HBase/Sqoop/Oozie-era components and modern replacements in migration | Clear replacement/compatibility/operations rationale |
| 07.01 | NoSQL families | Select key-value/document/wide-column/graph by access patterns and consistency | Key/query model and correctness test |
| 07.02 | MongoDB, Cassandra, HBase, Redis | Model document embedding, Cassandra partition/cluster keys, HBase row keys, Redis TTL/eviction | Workload-specific query and failure test |
| 08.01 | Analytical/OLAP DBs | Evaluate ClickHouse and OLAP warehouses separately from transactional store | Measured aggregation latency and ingest semantics |
| 09.01 | Specialized databases | Decide TSDB vs SQL vs search vs graph, based on operations | Time-range query, search relevance or graph traversal validation |
| 10.01 | Messaging fundamentals | Choose queue/stream/pub-sub/direct API; set acknowledgment and DLQ | Retry, replay, duplicate and queue depth tests |
| 10.02 | Kafka internals | Topic/key/partition, broker reliability, lag/retention, producer/client correctness | Partition spread, ISR/config and retention tests |
| 10.03 | Kafka systems | Kafka Streams/Connect, outbox, events, consumer groups and effect correctness | DB commit-vs-offset crash test |
| 10.04 | MQTT & IoT | Session/QoS/retained/LWT/shared subscriptions, MQTT-to-Kafka bridge | Offline reconnect, broker ack and missing-event audit |
| 10.05 | Cloud/alternative messaging | SQS/SNS, Kinesis/MSK, Pub/Sub, Event Hubs/Service Bus, Pulsar, NATS, Redis Streams | Service-specific contracts, ordering, retention and cost comparison |
| 11.01 | Distributed processing | Partition/shuffle/stages/tasks/state execution design | Stage plan and skew test |
| 11.02 | Spark | DataFrame/Spark SQL, batch/structured streaming, shuffle/AQE, cache | Spark UI metrics, plan correctness and recovery tests |
| 11.03 | Flink | Event-time, watermarks, state/checkpoints, TaskManagers, sinks/backpressure | Checkpoint restore and output reconciliation |
| 12.01 | Data lakes & object storage | Choose durable blob store, metadata/partition layout, hot/cold storage | File lifecycle, retrieval and permission tests |
| 13.01 | Lakehouse table formats | Iceberg/Delta/Hudi transactional commits, snapshots, schema evolution, compaction | Concurrent write/read and historical correction tests |
| 14.01 | Warehousing | Model dimensional marts, ETL/ELT boundary, warehouse compute/concurrency | BI grain, query SLAs and published data quality |
| 14.02 | Distributed SQL federation | Choose Trino/Athena/Presto/other engines for query pushdown and cross-source access | Remote bytes/plan/cost and access behavior |
| 15.01 | Integration | API pagination, incremental extracts, files, quality/quarantine, pipelines | Zero silent drops under errors and reruns |
| 16.01 | CDC | WAL snapshot/log handoff, Debezium, deletes, ordering, schema changes | Initial snapshot + ongoing updates consistency |
| 17.01 | Orchestration | Airflow DAG dependencies, retries/pools/backfills/intervals | Job queue vs run time, idempotent rerun tests |
| 18.01 | Transformation | dbt staging/models/incremental tests/docs/lineage | Model contract and correct merges/backfills |
| 19.01 | Analytics/BI | Define KPIs, semantic metrics, BI access patterns and DAX where appropriate | Metric definitions validated with row-level examples |
| 20.01 | Data quality | Test validity, completeness, uniqueness, consistency, timeliness, accuracy | Automated gates, quarantine and source-to-sink recon |
| 21.01 | Governance/lineage | Metadata, catalog, ownership, business glossary, column lineage, retention/disposal | Searchable discoverable products and impact analysis |
| 22.01 | Security | IAM/RBAC/ABAC, TLS/KMS, secrets, RLS/masking, audit | Least-privilege and cross-tenant denial tests |
| 23.01 | Observability | Logs/metrics/traces, OTel, Prometheus, Grafana, Kibana, ELK, SLOs | Dashboard, alert, fresh-data and incident tracing |
| 24.01 | Infrastructure | Local/native/Docker/Compose/Kubernetes/managed cloud choices | Reproducible runtime, ports/volumes and costs |
| 25.01 | Troubleshooting | SQL plans, skew/shuffle, Kafka lag, Flink backpressure, IO/network diagnosis | Evidence-based before/after benchmark |
| 26.01 | Reliability/DR | Exactly-once boundaries, backup/PITR, replay, RPO/RTO, test recovery | Crash-after-write, restore and reconciliation drills |
| 27.01 | Architecture patterns | Requirements→workload→design→tools; Lambda/Kappa/medallion/event-driven/data mesh | Justification and alternative with diagram |
| 28.01* | Technology-selection playbook | Hard constraints, shortlist, scorecard, TCO, POC and ADR | Traced selection rationale with measured evidence |

`*` 28.01 is based on the latest conversation draft; the supplied Apple Notes PDF export predates that note. Do not falsely cite it as an exported PDF.

## Five whole-platform integration checks
1. **SQL / OLTP → CDC → lakehouse → BI:** source transactions, delete/upsert, fact grain, SCD2, KPI math and access controls stay consistent.
2. **Device → MQTT → log → Flink → OLAP:** offline/replay/partition skew and sink write semantics do not produce missing or duplicate visible results.
3. **File/API → Airflow → dbt → marts:** pagination, late correction, incremental merge, publish freshness and consumer tests survive partial task failure.
4. **Any path → catalog/security/observability:** ownership, lineage, access controls and reliable SLIs must accompany the actual data, not merely appear in diagram boxes.
5. **Production → failure → restore:** backups/source retention/checkpoints reconcile to a correct post-recovery output and a measured RPO/RTO.
