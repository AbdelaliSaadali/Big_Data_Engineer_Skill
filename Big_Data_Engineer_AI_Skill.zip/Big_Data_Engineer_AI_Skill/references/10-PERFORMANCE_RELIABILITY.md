# Performance diagnosis, correctness under failure and disaster recovery

**Curriculum grounding:** 25.01 Optimizing & Troubleshooting Data Systems and 26.01 Reliable Data Systems & Disaster Recovery; 02.03/04/10/11 supporting internals.

## A. Performance loop
1. Reproduce same result and workload; establish baseline with p50/p95/p99 and throughput.
2. Measure stage rates, duration, data volume and resource utilization (CPU, RAM, GC, network, disk, locks, queues, concurrency).
3. Localize the *first* bottleneck with boundary measurements; distinguish “waiting” from “executing slowly.”
4. Hypothesize from evidence; change one thing; rerun comparable workload.
5. Verify correctness, regression, throughput under peak and recovery headroom. Record before/after actual numbers.

## B. Query and data-layout diagnosis
| Symptom | Inspect first | Evidence-based candidate optimization |
|---|---|---|
| PostgreSQL slow query | `EXPLAIN (ANALYZE, BUFFERS)`, rows estimated vs actual, locks | index, query predicate, statistics, join plan, transactions |
| SQL sort or join high cost | plan, spill, input cardinality | reduce input, appropriate sort/index, join algorithm |
| Lakehouse huge scan | partition/file pruning, column read, file count | partition design, compaction, projection/format |
| ClickHouse expensive queries | sorted key, granules read, query profile | more selective filters, data skipping, projections/materialization |
| Spark stage long tail | per-task size/duration and hot key | AQE, skew handling, key salting where correct |
| Spark slow shuffle | shuffle read/write, fetch wait, spill, GC | predicate pushdown, broadcast small side, rebalance |
| Kafka lag increases | ingress vs consume rates, per-partition lag, rebalances | fix slow sink/hot partition, concurrency if useful |
| Flink source backpressure | operator busy/backpressured/idle, sink writes | correct downstream capacity, batch/write tuning |
| Airflow pipeline late | queued vs running time, dependencies | executor/pools vs slow SQL/transform |
| Slow object storage | small file count, network placement, request rate | compaction, co-location, caching if justified |

Cost of `EXPLAIN` vs `EXPLAIN ANALYZE`: latter executes query; do not run destructive SQL without safeguards. Planner cost isn't milliseconds; sequential scans are not automatically inefficient; `LIMIT` doesn't guarantee few rows scanned. Optimize actual bottleneck rather than scaling all workers.

## C. Reliability boundary design
For each edge write a failure matrix:
```
Producer emits → broker durable ack → consumer reads → processor state checkpoint
→ sink writes/commits → consumer progress saved → dashboard reads
```
Answer crash-before-ack, crash-after-write-before-progress, duplicate delivery, network partition, retention expiry, poison record, sink outage, checkpoint loss, catalog corruption, regional outage. For every case specify loss, duplicate or delay possibility and recovery action.

**Exactly-once must be scoped**: MQTT QoS 2 concerns protocol delivery; Kafka transactions concern configured Kafka workflows; Flink checkpoints preserve consistent managed processing state; sink exactly-once effects need transactional/idempotent protocol or reconciliation. `UPSERT` by stable event ID can make event insertion idempotent, but `count=count+1` can still duplicate an aggregate unless atomic dedup is coupled to the increment.

## D. Backup/replay/checkpoint separation
- **Replication**: copies help availability; incorrect updates can replicate too.
- **Backup**: independent recoverable historical copy; test restoration, access keys and integrity.
- **PITR**: PostgreSQL base backup + required archived WAL to selected time; `pg_dump` isn't WAL-based arbitrary PITR.
- **Checkpoint**: state + consistent source progress. Can't recreate missing input log; store durably.
- **Replay**: requires source records still retained and sink safe under duplicate/recomputed output.
- **Table snapshot**: reference metadata and files; not automatic independent backup.

## E. RPO/RTO recovery specifications
RPO is maximum acceptable lost-history window; RTO is maximum acceptable outage duration. Define critical workload, failure scope and measurable recovery point/service recovery endpoint. Actual restore timing should include application verification, not just starting database process. 13:45 latest data, 14:00 failure → 15 min RPO gap; 14:40 fully restored → 40 min recovery duration. Do not equate stale dashboard with permanent RPO loss.

## F. Disaster-recovery designs
Backup/restore, pilot light, warm standby and active/active trade cost, failover speed and consistency. Multi-AZ and cross-region protect different failure scopes. Stateful replication/leader authority and failback must prevent split brain. Infrastructure-as-code, keys/config, runtime versions, schema/catalog/backups and data positions must be recoverable together.

## G. Recovery test suite
- Restart processing worker from checkpoint and verify exact per-key aggregates.
- Stop sink briefly: prove retained source and successful backlog catch-up; check duplicates.
- Replay selected window into isolated staging output; reconcile event ID sets and aggregate totals.
- Restore PostgreSQL backup/WAL to test environment and verify target timestamp.
- Test late event schema changes and source delete/CDC replay behavior.
- Confirm RPO/RTO against runbooks, secrets/key access and infrastructure provisioning time.
- Test stop/rollback path safely; do not inject faults in production absent approved game-day plan.

## H. Template evidence (no invented pass)
| Test ID | Scenario | Expected invariant | Observed | Pass? |
|---|---|---|---|---|
| REL-01 | consumer crash after sink write | no duplicate logical effect | pending | pending |
| REL-02 | source retention boundary | recoverable range defined | pending | pending |
| REL-03 | checkpoint + Kafka replay | state/result matches baseline | pending | pending |
| REL-04 | full restore | RPO/RTO satisfied | pending | pending |
