# Implementation protocol: from diagram to tested, operated deliverable

**Basis:** Applied engineering synthesis from curriculum notes 02–27 and 28.01 playbook. Examples are templates requiring adaptation to actual versions, infrastructure and interfaces.

## A. Definition of done
A data pipeline isn't done when data flows once. It needs documented source and target contracts, schema migrations, correctness under retries and late data, repeatable deployment, tests, monitoring, security, recovery and ownership.

## B. Repository pattern (tailor, don't cargo cult)
```
project/
  README.md                  # architecture, assumptions, setup, validation status
  docs/architecture.md       # diagram and ADR links
  docs/data_contracts/       # source/target definitions, schema versions, ownership
  docs/lineage.md            # datasets/columns and jobs
  docs/runbooks/             # incident/recovery procedures
  infrastructure/            # Docker Compose, Terraform, IAM, deploy manifests as needed
  src/ingest/                # validated adapters with retries and idempotency
  src/processing/            # SQL, PySpark, Flink jobs or Python
  transformations/           # dbt project when justified
  migrations/                # schema changes
  tests/unit/
  tests/integration/
  tests/data_quality/
  tests/failure_recovery/
  tests/performance/
  config/                    # safe examples, no secrets
  .github/workflows/         # CI if repository uses GitHub
```
Use only directories needed. Don't create a large empty scaffold just for appearances.

## C. Vertical slice recipe
1. Minimal ingestion: one real/synthetic event satisfying contract and one invalid event.
2. Explicit schema DDL with keys, owner and units, and example row.
3. Transform with traceable input → operation → output, side path for rejects.
4. Output with stable merge key; prove retry doesn't change logical result.
5. End-to-end test verifies single-record and batch/stream equivalent metric.
6. Add replay/late update/delete cases; document expected behavior.
7. Add operational dashboards and alerts, auth/permissions and backup/restore tests.
8. Load test representative normal/peak and measure in situ.

## D. Testing pyramid and invariants
**Unit**: parsing, validations, calculation with explicit units, temporal rounding, quality rules, dedup key, handling malformed payload.
**Contract/schema**: required fields, compatibility, unknown extra fields, delete/update semantics, version mismatch.
**Integration**: source/broker/engine/storage with realistic retries and connection failure; avoid relying solely on mocks.
**End-to-end**: data counts, source ID reconciliation, grain uniqueness, expected output rows, freshness and permissions.
**Resilience**: restart consumer after sink commit; source retention; checkpoint restore; sink outage; rerun backfill; backup restore.
**Performance**: sustained peak, p95/p99 freshness, worst hot key, downstream throttling, backlog catch-up, cost estimate.
**Security**: unauthorized tenant read, missing token, secret leakage, TLS and audit.

Example quality SQL:
```sql
-- Duplicated logical event IDs
SELECT event_id, COUNT(*) AS n
FROM processed_events
GROUP BY event_id
HAVING COUNT(*) > 1;

-- Duplicate analytical grain
SELECT event_date, device_id, COUNT(*) AS n
FROM device_daily_energy
GROUP BY event_date, device_id
HAVING COUNT(*) > 1;
```
Returning zero rows is necessary for these invariants but not sufficient for complete correctness. Run null/range/coverage/reconciliation checks too.

## E. Acceptance-case specification
```
Given: event E1 at 10:00 with 300 W held for 300 seconds
When: valid and unique, transformed to energy_kwh
Then: result = 300*300/3600000 = 0.025 kWh
And: repeating E1 does not increase same logical energy result
And: event_time/ingested_at are preserved for freshness measurement
```
Define expected behavior for out-of-order, missing, late, correction, deletion and invalid; don't silently assume drop or accept.

## F. Change and migration discipline
- Schema changes: migration script, compatibility matrix, downstream impact from lineage, dual-read/write if needed, backward plan.
- Historical backfills: explicit interval boundaries, deterministic source snapshot, destination idempotency/atomic replacement, state cleanup and tests.
- Deployment: version pin, dependency scan, rollback, separation of test/prod, approved secrets and safe SQL.
- Data migration: compare source and target by key/time/metric, audit exclusions, parallel run, cutover authority and validation report.

## G. Evidence report format
```
Design status: proposed / implemented / deployed
Environments tested: local/staging/prod (exact)
Data volume: observed or synthetic, dates and shapes
Tests: command and results (actual; attach logs/reports if available)
Performance: p50/p95/p99, rates, environment, repeatability
Reliability: failures injected safely, recovery and reconciliation
Security: permissions validated by denied-access tests
Unknowns / blockers / next actions
```
Do not claim “exactly once”, “scales to millions” or “production ready” without bounded, reproducible evidence.
