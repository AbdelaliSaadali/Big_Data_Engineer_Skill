# Source map — Apple Notes Big Data curriculum

These are text extracts from user-provided PDFs in `Apple Notes Export.zip`, generated for AI retrieval. They retain source concepts but some PDF formatting/tables/figures may be flattened. Refer to original PDFs for precise layouts and diagrams. The export does not include note 28.01; the selection playbook in this skill is also informed by the conversation’s 28.01 draft, rather than claiming it is in the export.

| Note | Title | Pages | Extracted file |
|---|---|---:|---|
| 00.01 | What Is the Data Field | 23 | [`00.01-what-is-the-data-field.md`](../knowledge/source_notes/00.01-what-is-the-data-field.md) |
| 00.02 | Data Engineer vs Data Analyst vs Data Scientist vs DBA | 13 | [`00.02-data-engineer-vs-data-analyst-vs-data-scientist-vs-dba.md`](../knowledge/source_notes/00.02-data-engineer-vs-data-analyst-vs-data-scientist-vs-dba.md) |
| 00.03 | Big Data Explained | 14 | [`00.03-big-data-explained.md`](../knowledge/source_notes/00.03-big-data-explained.md) |
| 01.01 | Data Fundamentals & Workload Vocabulary | 15 | [`01.01-data-fundamentals-workload-vocabulary.md`](../knowledge/source_notes/01.01-data-fundamentals-workload-vocabulary.md) |
| 02.01 | Relational Model & SQL Fundamentals | 11 | [`02.01-relational-model-sql-fundamentals.md`](../knowledge/source_notes/02.01-relational-model-sql-fundamentals.md) |
| 02.02 | Joins, Aggregations, Subqueries, CTEs & Window Functions | 17 | [`02.02-joins-aggregations-subqueries-ctes-window-functions.md`](../knowledge/source_notes/02.02-joins-aggregations-subqueries-ctes-window-functions.md) |
| 02.03 | How Relational Databases Work | 12 | [`02.03-how-relational-databases-work.md`](../knowledge/source_notes/02.03-how-relational-databases-work.md) |
| 03.01 | Operational Data Modeling | 16 | [`03.01-operational-data-modeling.md`](../knowledge/source_notes/03.01-operational-data-modeling.md) |
| 03.02 | Analytical Data Modeling | 19 | [`03.02-analytical-data-modeling.md`](../knowledge/source_notes/03.02-analytical-data-modeling.md) |
| 04.01 | Distributed Systems Fundamentals | 15 | [`04.01-distributed-systems-fundamentals.md`](../knowledge/source_notes/04.01-distributed-systems-fundamentals.md) |
| 04.02 | Partitioning, Replication & Consistency | 23 | [`04.02-partitioning-replication-consistency.md`](../knowledge/source_notes/04.02-partitioning-replication-consistency.md) |
| 04.03 | Coordination & Fault Tolerance | 21 | [`04.03-coordination-fault-tolerance.md`](../knowledge/source_notes/04.03-coordination-fault-tolerance.md) |
| 05.01 | How Data Is Stored | 21 | [`05.01-how-data-is-stored.md`](../knowledge/source_notes/05.01-how-data-is-stored.md) |
| 05.02 | Data File Formats | 21 | [`05.02-data-file-formats.md`](../knowledge/source_notes/05.02-data-file-formats.md) |
| 06.01 | Hadoop Core | 21 | [`06.01-hadoop-core.md`](../knowledge/source_notes/06.01-hadoop-core.md) |
| 06.02 | Hadoop Ecosystem & Its Modern Relevance | 20 | [`06.02-hadoop-ecosystem-its-modern-relevance.md`](../knowledge/source_notes/06.02-hadoop-ecosystem-its-modern-relevance.md) |
| 07.01 | NoSQL Fundamentals & Database Families | 28 | [`07.01-nosql-fundamentals-database-families.md`](../knowledge/source_notes/07.01-nosql-fundamentals-database-families.md) |
| 07.02 | MongoDB, Cassandra, HBase & Redis | 22 | [`07.02-mongodb-cassandra-hbase-redis.md`](../knowledge/source_notes/07.02-mongodb-cassandra-hbase-redis.md) |
| 08.01 | OLAP Systems & Analytical Databases | 23 | [`08.01-olap-systems-analytical-databases.md`](../knowledge/source_notes/08.01-olap-systems-analytical-databases.md) |
| 09.01 | Time-Series, Search & Graph Databases | 25 | [`09.01-time-series-search-graph-databases.md`](../knowledge/source_notes/09.01-time-series-search-graph-databases.md) |
| 10.01 | Messaging & Event Streaming Fundamentals | 20 | [`10.01-messaging-event-streaming-fundamentals.md`](../knowledge/source_notes/10.01-messaging-event-streaming-fundamentals.md) |
| 10.02 | Apache Kafka Architecture | 28 | [`10.02-apache-kafka-architecture.md`](../knowledge/source_notes/10.02-apache-kafka-architecture.md) |
| 10.03 | Kafka in Real Systems | 31 | [`10.03-kafka-in-real-systems.md`](../knowledge/source_notes/10.03-kafka-in-real-systems.md) |
| 10.04 | MQTT & IoT Messaging Systems | 30 | [`10.04-mqtt-iot-messaging-systems.md`](../knowledge/source_notes/10.04-mqtt-iot-messaging-systems.md) |
| 10.05 | Cloud Messaging & Alternative Messaging Systems | 25 | [`10.05-cloud-messaging-alternative-messaging-systems.md`](../knowledge/source_notes/10.05-cloud-messaging-alternative-messaging-systems.md) |
| 11.01 | Distributed Data Processing Fundamentals | 24 | [`11.01-distributed-data-processing-fundamentals.md`](../knowledge/source_notes/11.01-distributed-data-processing-fundamentals.md) |
| 11.02 | Apache Spark | 28 | [`11.02-apache-spark.md`](../knowledge/source_notes/11.02-apache-spark.md) |
| 11.03 | Apache Flink & Stream Processing | 22 | [`11.03-apache-flink-stream-processing.md`](../knowledge/source_notes/11.03-apache-flink-stream-processing.md) |
| 12.01 | Data Lakes, HDFS & Object Storage | 18 | [`12.01-data-lakes-hdfs-object-storage.md`](../knowledge/source_notes/12.01-data-lakes-hdfs-object-storage.md) |
| 13.01 | Lakehouse Architecture & Table Formats | 19 | [`13.01-lakehouse-architecture-table-formats.md`](../knowledge/source_notes/13.01-lakehouse-architecture-table-formats.md) |
| 14.01 | Data Warehouses From Fundamentals to Modern Systems | 24 | [`14.01-data-warehouses-from-fundamentals-to-modern-systems.md`](../knowledge/source_notes/14.01-data-warehouses-from-fundamentals-to-modern-systems.md) |
| 14.02 | Distributed SQL Query Engines & Federation | 22 | [`14.02-distributed-sql-query-engines-federation.md`](../knowledge/source_notes/14.02-distributed-sql-query-engines-federation.md) |
| 15.01 | ETL, ELT & Data Integration Patterns | 22 | [`15.01-etl-elt-data-integration-patterns.md`](../knowledge/source_notes/15.01-etl-elt-data-integration-patterns.md) |
| 16.01 | Change Data Capture (CDC) | 25 | [`16.01-change-data-capture-cdc.md`](../knowledge/source_notes/16.01-change-data-capture-cdc.md) |
| 17.01 | Data Orchestration | 21 | [`17.01-data-orchestration.md`](../knowledge/source_notes/17.01-data-orchestration.md) |
| 18.01 | Data Transformation & dbt | 23 | [`18.01-data-transformation-dbt.md`](../knowledge/source_notes/18.01-data-transformation-dbt.md) |
| 19.01 | Analytics, Metrics & Business Intelligence | 23 | [`19.01-analytics-metrics-business-intelligence.md`](../knowledge/source_notes/19.01-analytics-metrics-business-intelligence.md) |
| 20.01 | Data Quality Engineering | 24 | [`20.01-data-quality-engineering.md`](../knowledge/source_notes/20.01-data-quality-engineering.md) |
| 21.01 | Governance, Metadata, Catalogs & Data Lifecycle | 38 | [`21.01-governance-metadata-catalogs-data-lifecycle.md`](../knowledge/source_notes/21.01-governance-metadata-catalogs-data-lifecycle.md) |
| 22.01 | Data Security Fundamentals | 32 | [`22.01-data-security-fundamentals.md`](../knowledge/source_notes/22.01-data-security-fundamentals.md) |
| 23.01 | Data Observability | 23 | [`23.01-data-observability.md`](../knowledge/source_notes/23.01-data-observability.md) |
| 24.01 | How Data Technologies Run Docker, Kubernetes & Cloud Infrastructure | 32 | [`24.01-how-data-technologies-run-docker-kubernetes-cloud-infrastructure.md`](../knowledge/source_notes/24.01-how-data-technologies-run-docker-kubernetes-cloud-infrastructure.md) |
| 25.01 | Optimizing & Troubleshooting Data Systems | 41 | [`25.01-optimizing-troubleshooting-data-systems.md`](../knowledge/source_notes/25.01-optimizing-troubleshooting-data-systems.md) |
| 26.01 | Reliable Data Systems & Disaster Recovery | 39 | [`26.01-reliable-data-systems-disaster-recovery.md`](../knowledge/source_notes/26.01-reliable-data-systems-disaster-recovery.md) |
| 27.01 | Architecture Patterns & How to Design a Data System | 42 | [`27.01-architecture-patterns-how-to-design-a-data-system.md`](../knowledge/source_notes/27.01-architecture-patterns-how-to-design-a-data-system.md) |
| ROADMAP | Big Data | 5 | [`ROADMAP-big-data.md`](../knowledge/source_notes/ROADMAP-big-data.md) |
